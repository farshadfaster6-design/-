export type RateSource = "union-1404" | "estimated" | "union-1405";
export type QtyKind = "fixed" | "perSide" | "perUnit" | "both";
export type BrandId =
  | "saipa"
  | "ikco"
  | "renault"
  | "hyundai"
  | "kia"
  | "toyota"
  | "lexus"
  | "china";
export type FamilyId =
  | "pride"
  | "tiba"
  | "ikco405"
  | "ikco206"
  | "dena"
  | "l90"
  | "megane"
  | "verna"
  | "hyundaiMid"
  | "hyundaiSuv"
  | "kiaCerato"
  | "kiaSuv"
  | "toyotaCompact"
  | "toyotaCamry"
  | "toyotaSuv"
  | "toyotaPrado"
  | "lexusSedan"
  | "lexusSuv"
  | "china";
export type CategoryId =
  | "package"
  | "mount"
  | "arm"
  | "steering"
  | "shock"
  | "sway"
  | "subframe"
  | "align";

export interface ServiceDef {
  id: string;
  name: string;
  category: CategoryId;
  qtyKind: QtyKind;
  unitLabel: string;
  maxQty: number;
  hint?: string;
}

export interface CarDef {
  id: string;
  name: string;
  brand: BrandId;
  family: FamilyId;
}

export interface RateCell {
  toman: number;
  source: RateSource;
}

export const CATEGORIES: { id: CategoryId; name: string }[] = [
  { id: "package", name: "پکیج کامل" },
  { id: "mount", name: "دسته‌موتور" },
  { id: "arm", name: "طبق و بوش" },
  { id: "steering", name: "فرمان و جعبه فرمان" },
  { id: "shock", name: "کمک‌فنر و سگدست" },
  { id: "sway", name: "موج‌گیر" },
  { id: "subframe", name: "رام" },
  { id: "align", name: "میزان فرمان" },
];

export const BRANDS: { id: BrandId; name: string }[] = [
  { id: "saipa", name: "سایپا" },
  { id: "ikco", name: "ایران‌خودرو" },
  { id: "renault", name: "رنو" },
  { id: "hyundai", name: "هیوندای" },
  { id: "kia", name: "کیا" },
  { id: "toyota", name: "تویوتا" },
  { id: "lexus", name: "لکسوس" },
  { id: "china", name: "چینی" },
];

export const CARS: CarDef[] = [
  { id: "pride", name: "پراید", brand: "saipa", family: "pride" },
  { id: "tiba", name: "تیبا", brand: "saipa", family: "tiba" },
  { id: "saina", name: "ساینا", brand: "saipa", family: "tiba" },
  { id: "quick", name: "کوییک", brand: "saipa", family: "tiba" },
  { id: "rio", name: "ریو", brand: "saipa", family: "tiba" },
  { id: "mazda", name: "وانت مزدا", brand: "saipa", family: "ikco206" },
  { id: "405", name: "پژو ۴۰۵", brand: "ikco", family: "ikco405" },
  { id: "pars", name: "پژو پارس", brand: "ikco", family: "ikco405" },
  { id: "samand", name: "سمند", brand: "ikco", family: "ikco405" },
  { id: "samand-ef7", name: "سمند EF7", brand: "ikco", family: "ikco405" },
  { id: "206", name: "پژو ۲۰۶", brand: "ikco", family: "ikco206" },
  { id: "207", name: "پژو ۲۰۷", brand: "ikco", family: "ikco206" },
  { id: "rana", name: "رانا", brand: "ikco", family: "ikco206" },
  { id: "dena", name: "دنا", brand: "ikco", family: "dena" },
  { id: "dena-plus", name: "دنا پلاس", brand: "ikco", family: "dena" },
  { id: "l90", name: "تندر ۹۰", brand: "renault", family: "l90" },
  { id: "sandro", name: "ساندرو", brand: "renault", family: "l90" },
  { id: "megane", name: "مگان", brand: "renault", family: "megane" },
  { id: "verna", name: "ورنا", brand: "hyundai", family: "verna" },
  { id: "accent", name: "اکسنت", brand: "hyundai", family: "verna" },
  { id: "i20", name: "i20", brand: "hyundai", family: "verna" },
  { id: "elantra", name: "النترا", brand: "hyundai", family: "verna" },
  { id: "avante", name: "آوانته", brand: "hyundai", family: "verna" },
  { id: "sonata", name: "سوناتا", brand: "hyundai", family: "hyundaiMid" },
  { id: "tucson", name: "توسان", brand: "hyundai", family: "hyundaiMid" },
  { id: "ix35", name: "ix35", brand: "hyundai", family: "hyundaiMid" },
  { id: "santafe", name: "سانتافه", brand: "hyundai", family: "hyundaiSuv" },
  { id: "cerato", name: "سراتو", brand: "kia", family: "kiaCerato" },
  { id: "optima", name: "اپتیما", brand: "kia", family: "kiaCerato" },
  { id: "sportage", name: "اسپورتیج", brand: "kia", family: "kiaSuv" },
  { id: "sorento", name: "سورنتو", brand: "kia", family: "kiaSuv" },
  { id: "yaris", name: "یاریس", brand: "toyota", family: "toyotaCompact" },
  { id: "corolla", name: "کرولا", brand: "toyota", family: "toyotaCompact" },
  { id: "camry", name: "کمری", brand: "toyota", family: "toyotaCamry" },
  { id: "rav4", name: "RAV4", brand: "toyota", family: "toyotaSuv" },
  { id: "hilux", name: "هایلوکس", brand: "toyota", family: "toyotaPrado" },
  { id: "prado", name: "پرادو", brand: "toyota", family: "toyotaPrado" },
  { id: "landcruiser", name: "لندکروز", brand: "toyota", family: "toyotaPrado" },
  { id: "lexus-is", name: "لکسوس IS", brand: "lexus", family: "lexusSedan" },
  { id: "lexus-es", name: "لکسوس ES", brand: "lexus", family: "lexusSedan" },
  { id: "lexus-nx", name: "لکسوس NX", brand: "lexus", family: "lexusSuv" },
  { id: "lexus-rx", name: "لکسوس RX", brand: "lexus", family: "lexusSuv" },
  { id: "jac-s5", name: "جک S5", brand: "china", family: "china" },
  { id: "jac-j5", name: "جک J5", brand: "china", family: "china" },
  { id: "arrizo5", name: "آریزو ۵", brand: "china", family: "china" },
  { id: "tiggo5", name: "تیگو ۵", brand: "china", family: "china" },
  { id: "x33", name: "ام‌وی‌ام X33", brand: "china", family: "china" },
];

export const SERVICES: ServiceDef[] = [
  {
    id: "full_front",
    name: "تعمیر کامل جلوبندی",
    category: "package",
    qtyKind: "fixed",
    unitLabel: "دستمزد کامل",
    maxQty: 1,
    hint: "نرخ مصوب ۱۴۰۵ اتحادیه تهران؛ بدون احتساب قطعات و کمک‌فنر جداگانه",
  },
  {
    id: "full_no_shock",
    name: "تعمیر کامل جلوبندی بدون کمک",
    category: "package",
    qtyKind: "fixed",
    unitLabel: "دستمزد کامل",
    maxQty: 1,
    hint: "پکیج بدون تعویض کمک‌فنر",
  },
  {
    id: "mount_upper",
    name: "تعویض دسته‌موتور بالا راست",
    category: "mount",
    qtyKind: "fixed",
    unitLabel: "عدد",
    maxQty: 1,
  },
  {
    id: "mount_front",
    name: "تعویض پایه دسته‌موتور جلو یا چپ",
    category: "mount",
    qtyKind: "fixed",
    unitLabel: "عدد",
    maxQty: 1,
  },
  {
    id: "mount_round",
    name: "تعویض دسته‌موتور جلو گرد",
    category: "mount",
    qtyKind: "fixed",
    unitLabel: "عدد",
    maxQty: 1,
  },
  {
    id: "control_arm",
    name: "باز و بست طبق",
    category: "arm",
    qtyKind: "both",
    unitLabel: "هر دو طرف",
    maxQty: 1,
    hint: "نرخ برای هر دو طرف است",
  },
  {
    id: "arm_bush",
    name: "تعویض بوش طبق",
    category: "arm",
    qtyKind: "perUnit",
    unitLabel: "هر عدد",
    maxQty: 4,
  },
  {
    id: "lower_ball",
    name: "تعویض سیبک زیر کمک",
    category: "arm",
    qtyKind: "perSide",
    unitLabel: "هر طرف",
    maxQty: 2,
  },
  {
    id: "tie_rod",
    name: "تعویض سیبک فرمان",
    category: "steering",
    qtyKind: "perSide",
    unitLabel: "هر طرف",
    maxQty: 2,
  },
  {
    id: "inner_tie",
    name: "تعویض قرقری فرمان",
    category: "steering",
    qtyKind: "perSide",
    unitLabel: "هر طرف",
    maxQty: 2,
  },
  {
    id: "bellows",
    name: "تعویض گردگیر فرمان",
    category: "steering",
    qtyKind: "perSide",
    unitLabel: "هر طرف",
    maxQty: 2,
  },
  {
    id: "steering_box",
    name: "باز و بست و تعمیر کامل جعبه فرمان",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
    hint: "پیاده و سوار کردن جعبه فرمان و تعمیر کامل داخل جعبه؛ بدون قطعه",
  },
  {
    id: "hyd_pump",
    name: "تعویض پمپ هیدرولیک فرمان",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "hyd_pump_repair",
    name: "تعمیر پمپ هیدرولیک فرمان",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "hyd_reservoir",
    name: "تعویض منبع هیدرولیک فرمان",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "hyd_hose_high",
    name: "تعویض شلنگ فشار قوی هیدرولیک",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "hyd_hose_low",
    name: "تعویض شلنگ فشار ضعیف هیدرولیک",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "hyd_hose_to_box",
    name: "تعویض شلنگ منبع به جعبه فرمان",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "eps_motor",
    name: "تعویض موتور برقی فرمان",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
    hint: "برای خودروهای فرمان برقی (EPS)",
  },
  {
    id: "steering_cross",
    name: "تعویض چهارشاخه فرمان",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "steering_tele",
    name: "باز و بست تلسکوپی فرمان",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "hyd_hoses",
    name: "تعویض لوله‌های هیدرولیک",
    category: "steering",
    qtyKind: "fixed",
    unitLabel: "جفت",
    maxQty: 1,
  },
  {
    id: "front_shock",
    name: "تعویض کمک‌فنر جلو",
    category: "shock",
    qtyKind: "perUnit",
    unitLabel: "هر عدد",
    maxQty: 2,
  },
  {
    id: "rear_shock",
    name: "تعویض کمک‌فنر عقب",
    category: "shock",
    qtyKind: "perUnit",
    unitLabel: "هر عدد",
    maxQty: 2,
  },
  {
    id: "knuckle_bearing",
    name: "تعویض بلبرینگ چرخ جلو و باز و بست سگدست",
    category: "shock",
    qtyKind: "perSide",
    unitLabel: "هر طرف",
    maxQty: 2,
  },
  {
    id: "sway_bush",
    name: "تعویض لاستیک‌های چاک‌دار موج‌گیر",
    category: "sway",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "sway_bar",
    name: "تعویض میل موج‌گیر جلو",
    category: "sway",
    qtyKind: "perSide",
    unitLabel: "هر طرف",
    maxQty: 2,
  },
  {
    id: "subframe",
    name: "تعویض رام زیر موتور",
    category: "subframe",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "align_manual",
    name: "میزان فرمان دستی",
    category: "align",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "align_machine",
    name: "میزان فرمان با دستگاه",
    category: "align",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "wrenching",
    name: "آچارکشی جلوبندی",
    category: "align",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
  {
    id: "wheel_adj",
    name: "تنظیم غربیلک فرمان",
    category: "align",
    qtyKind: "fixed",
    unitLabel: "دستمزد",
    maxQty: 1,
  },
];

const U = "union-1404" as const;
const E = "estimated" as const;
const U5 = "union-1405" as const;

function r(toman: number, source: RateSource): RateCell {
  return { toman, source };
}

function scale(base: Record<string, RateCell>, factor: number): Record<string, RateCell> {
  const out: Record<string, RateCell> = {};
  for (const [id, cell] of Object.entries(base)) {
    out[id] = r(Math.round((cell.toman * factor) / 10_000) * 10_000, E);
  }
  return out;
}

/** اجرت جعبه فرمان و هیدرولیک — تومان */
function box(
  values: {
    steering_box: number;
    hyd_pump: number;
    hyd_pump_repair: number;
    hyd_reservoir: number;
    hyd_hose_high: number;
    hyd_hose_low: number;
    hyd_hose_to_box: number;
    eps_motor?: number;
  },
  source: RateSource,
): Record<string, RateCell> {
  const out: Record<string, RateCell> = {
    steering_box: r(values.steering_box, source),
    hyd_pump: r(values.hyd_pump, source),
    hyd_pump_repair: r(values.hyd_pump_repair, source),
    hyd_reservoir: r(values.hyd_reservoir, source),
    hyd_hose_high: r(values.hyd_hose_high, source),
    hyd_hose_low: r(values.hyd_hose_low, source),
    hyd_hose_to_box: r(values.hyd_hose_to_box, source),
  };
  if (values.eps_motor) out.eps_motor = r(values.eps_motor, E);
  return out;
}

/**
 * Individual rates in TOMAN.
 * union-1404: اتحادیه تهران، جدول جلوبندی ۸ دی ۱۴۰۴ (منبع به ریال؛ اینجا تومان).
 * estimated: ردیف‌های ناموجود در جدول دی ۱۴۰۴، با ضریب حدود ۱٫۹۷ از نرخ ۱۴۰۳.
 * union-1405: پکیج تعمیر کامل جلوبندی و اجرت جعبه فرمان از نرخ‌نامه ۱۴۰۵.
 */
const PRIDE_BOX = box(
  {
    steering_box: 1_500_000,
    hyd_pump: 600_000,
    hyd_pump_repair: 800_000,
    hyd_reservoir: 400_000,
    hyd_hose_high: 600_000,
    hyd_hose_low: 400_000,
    hyd_hose_to_box: 650_000,
  },
  U5,
);

const TIBA_BOX = box(
  {
    steering_box: 1_700_000,
    hyd_pump: 650_000,
    hyd_pump_repair: 900_000,
    hyd_reservoir: 450_000,
    hyd_hose_high: 650_000,
    hyd_hose_low: 400_000,
    hyd_hose_to_box: 700_000,
  },
  U5,
);

const IKCO405_BOX = box(
  {
    steering_box: 2_200_000,
    hyd_pump: 750_000,
    hyd_pump_repair: 1_200_000,
    hyd_reservoir: 550_000,
    hyd_hose_high: 750_000,
    hyd_hose_low: 450_000,
    hyd_hose_to_box: 800_000,
  },
  U5,
);

const IKCO206_BOX = box(
  {
    steering_box: 2_000_000,
    hyd_pump: 720_000,
    hyd_pump_repair: 1_100_000,
    hyd_reservoir: 520_000,
    hyd_hose_high: 720_000,
    hyd_hose_low: 430_000,
    hyd_hose_to_box: 760_000,
  },
  U5,
);

const DENA_BOX = box(
  {
    steering_box: 2_500_000,
    hyd_pump: 800_000,
    hyd_pump_repair: 1_500_000,
    hyd_reservoir: 650_000,
    hyd_hose_high: 800_000,
    hyd_hose_low: 500_000,
    hyd_hose_to_box: 850_000,
    eps_motor: 2_200_000,
  },
  U5,
);

const L90_BOX = box(
  {
    steering_box: 3_200_000,
    hyd_pump: 1_100_000,
    hyd_pump_repair: 1_800_000,
    hyd_reservoir: 800_000,
    hyd_hose_high: 1_100_000,
    hyd_hose_low: 650_000,
    hyd_hose_to_box: 1_200_000,
  },
  U5,
);

const VERNA_BOX = box(
  {
    steering_box: 4_800_000,
    hyd_pump: 1_800_000,
    hyd_pump_repair: 2_800_000,
    hyd_reservoir: 1_100_000,
    hyd_hose_high: 1_800_000,
    hyd_hose_low: 1_000_000,
    hyd_hose_to_box: 1_900_000,
    eps_motor: 3_200_000,
  },
  E,
);

const L90: Record<string, RateCell> = {
  mount_upper: r(850_000, U),
  mount_front: r(1_430_000, U),
  mount_round: r(1_240_000, E),
  sway_bush: r(650_000, U),
  sway_bar: r(350_000, E),
  tie_rod: r(500_000, U),
  inner_tie: r(930_000, U),
  bellows: r(790_000, E),
  control_arm: r(1_810_000, U),
  arm_bush: r(900_000, E),
  lower_ball: r(1_150_000, E),
  front_shock: r(1_240_000, U),
  rear_shock: r(990_000, E),
  knuckle_bearing: r(1_600_000, E),
  subframe: r(4_360_000, U),
  steering_cross: r(2_000_000, E),
  steering_tele: r(2_000_000, E),
  hyd_hoses: r(1_240_000, E),
  full_no_shock: r(2_380_000, E),
  align_manual: r(370_000, E),
  align_machine: r(470_000, E),
  wrenching: r(830_000, E),
  wheel_adj: r(180_000, E),
  ...L90_BOX,
};

const VERNA: Record<string, RateCell> = {
  mount_upper: r(1_300_000, U),
  mount_front: r(1_300_000, U),
  mount_round: r(1_600_000, E),
  sway_bush: r(840_000, E),
  sway_bar: r(670_000, E),
  tie_rod: r(800_000, U),
  inner_tie: r(900_000, U),
  bellows: r(1_160_000, E),
  control_arm: r(2_000_000, E),
  arm_bush: r(1_160_000, E),
  lower_ball: r(1_480_000, E),
  front_shock: r(1_600_000, U),
  rear_shock: r(1_280_000, E),
  knuckle_bearing: r(2_070_000, E),
  subframe: r(5_500_000, U),
  steering_cross: r(4_190_000, E),
  steering_tele: r(3_380_000, E),
  hyd_hoses: r(2_150_000, E),
  full_no_shock: r(3_540_000, E),
  align_manual: r(1_080_000, E),
  align_machine: r(1_370_000, E),
  wrenching: r(1_080_000, E),
  wheel_adj: r(230_000, E),
  ...VERNA_BOX,
};

const FAMILY_RATES: Record<FamilyId, Record<string, RateCell>> = {
  pride: {
    mount_upper: r(650_000, U),
    mount_front: r(650_000, U),
    mount_round: r(550_000, E),
    sway_bush: r(710_000, U),
    tie_rod: r(390_000, U),
    inner_tie: r(710_000, U),
    bellows: r(710_000, E),
    control_arm: r(940_000, U),
    arm_bush: r(400_000, E),
    lower_ball: r(510_000, E),
    front_shock: r(550_000, U),
    rear_shock: r(410_000, E),
    knuckle_bearing: r(710_000, E),
    subframe: r(690_000, U),
    steering_cross: r(1_440_000, E),
    steering_tele: r(1_160_000, E),
    full_no_shock: r(1_300_000, E),
    align_manual: r(370_000, E),
    align_machine: r(470_000, E),
    wrenching: r(370_000, E),
    wheel_adj: r(80_000, E),
    ...PRIDE_BOX,
  },
  tiba: {
    mount_upper: r(650_000, U),
    mount_front: r(650_000, U),
    mount_round: r(550_000, E),
    sway_bush: r(710_000, U),
    sway_bar: r(450_000, E),
    tie_rod: r(390_000, U),
    inner_tie: r(710_000, U),
    bellows: r(710_000, E),
    control_arm: r(940_000, U),
    arm_bush: r(400_000, E),
    lower_ball: r(510_000, E),
    front_shock: r(550_000, U),
    rear_shock: r(410_000, E),
    knuckle_bearing: r(710_000, E),
    subframe: r(690_000, U),
    steering_cross: r(1_440_000, E),
    steering_tele: r(1_160_000, E),
    hyd_hoses: r(1_100_000, E),
    full_no_shock: r(1_730_000, E),
    align_manual: r(370_000, E),
    align_machine: r(470_000, E),
    wrenching: r(370_000, E),
    wheel_adj: r(80_000, E),
    ...TIBA_BOX,
  },
  ikco405: {
    mount_upper: r(590_000, U),
    mount_front: r(420_000, U),
    mount_round: r(820_000, E),
    sway_bush: r(1_060_000, E),
    sway_bar: r(670_000, E),
    tie_rod: r(580_000, E),
    inner_tie: r(1_060_000, E),
    bellows: r(910_000, E),
    control_arm: r(1_400_000, E),
    arm_bush: r(600_000, E),
    lower_ball: r(760_000, E),
    front_shock: r(820_000, U),
    rear_shock: r(660_000, E),
    knuckle_bearing: r(1_060_000, E),
    subframe: r(2_420_000, U),
    steering_cross: r(2_150_000, E),
    steering_tele: r(1_730_000, E),
    hyd_hoses: r(1_300_000, E),
    full_no_shock: r(2_150_000, E),
    align_manual: r(550_000, E),
    align_machine: r(700_000, E),
    wrenching: r(550_000, E),
    wheel_adj: r(120_000, E),
    ...IKCO405_BOX,
  },
  ikco206: {
    mount_upper: r(550_000, U),
    mount_front: r(470_000, U),
    mount_round: r(820_000, E),
    sway_bush: r(451_000, E),
    sway_bar: r(294_000, E),
    tie_rod: r(294_000, E),
    inner_tie: r(451_000, E),
    bellows: r(910_000, E),
    control_arm: r(588_000, E),
    arm_bush: r(600_000, E),
    lower_ball: r(760_000, E),
    front_shock: r(823_000, E),
    rear_shock: r(660_000, E),
    knuckle_bearing: r(1_060_000, E),
    subframe: r(2_850_000, U),
    steering_cross: r(2_150_000, E),
    steering_tele: r(1_730_000, E),
    hyd_hoses: r(1_300_000, E),
    full_no_shock: r(2_150_000, E),
    align_manual: r(550_000, E),
    align_machine: r(700_000, E),
    wrenching: r(550_000, E),
    wheel_adj: r(120_000, E),
    ...IKCO206_BOX,
  },
  dena: {
    mount_upper: r(1_800_000, U),
    mount_front: r(550_000, U),
    mount_round: r(820_000, E),
    sway_bush: r(1_060_000, E),
    sway_bar: r(670_000, E),
    tie_rod: r(260_000, U),
    inner_tie: r(360_000, U),
    bellows: r(910_000, E),
    control_arm: r(1_300_000, U),
    arm_bush: r(600_000, E),
    lower_ball: r(760_000, E),
    front_shock: r(820_000, U),
    rear_shock: r(660_000, E),
    knuckle_bearing: r(1_060_000, E),
    subframe: r(3_090_000, U),
    steering_cross: r(2_150_000, E),
    steering_tele: r(1_730_000, E),
    hyd_hoses: r(1_300_000, E),
    full_no_shock: r(2_150_000, E),
    align_manual: r(550_000, E),
    align_machine: r(700_000, E),
    wrenching: r(550_000, E),
    wheel_adj: r(120_000, E),
    ...DENA_BOX,
  },
  l90: L90,
  megane: scale(L90, 2.6),
  verna: VERNA,
  hyundaiMid: {
    ...scale(VERNA, 1.22),
    ...box(
      {
        steering_box: 7_200_000,
        hyd_pump: 2_400_000,
        hyd_pump_repair: 3_600_000,
        hyd_reservoir: 1_400_000,
        hyd_hose_high: 2_400_000,
        hyd_hose_low: 1_300_000,
        hyd_hose_to_box: 2_500_000,
        eps_motor: 4_200_000,
      },
      E,
    ),
  },
  hyundaiSuv: {
    ...scale(VERNA, 1.42),
    ...box(
      {
        steering_box: 8_800_000,
        hyd_pump: 3_000_000,
        hyd_pump_repair: 4_400_000,
        hyd_reservoir: 1_700_000,
        hyd_hose_high: 3_000_000,
        hyd_hose_low: 1_600_000,
        hyd_hose_to_box: 3_100_000,
        eps_motor: 5_100_000,
      },
      E,
    ),
  },
  kiaCerato: {
    ...scale(VERNA, 1.1),
    ...box(
      {
        steering_box: 6_500_000,
        hyd_pump: 2_200_000,
        hyd_pump_repair: 3_300_000,
        hyd_reservoir: 1_250_000,
        hyd_hose_high: 2_200_000,
        hyd_hose_low: 1_150_000,
        hyd_hose_to_box: 2_300_000,
        eps_motor: 3_800_000,
      },
      E,
    ),
  },
  kiaSuv: {
    ...scale(VERNA, 1.28),
    ...box(
      {
        steering_box: 8_000_000,
        hyd_pump: 2_700_000,
        hyd_pump_repair: 4_000_000,
        hyd_reservoir: 1_550_000,
        hyd_hose_high: 2_700_000,
        hyd_hose_low: 1_450_000,
        hyd_hose_to_box: 2_800_000,
        eps_motor: 4_600_000,
      },
      E,
    ),
  },
  toyotaCompact: {
    ...scale(VERNA, 1.12),
    ...box(
      {
        steering_box: 6_800_000,
        hyd_pump: 2_300_000,
        hyd_pump_repair: 3_400_000,
        hyd_reservoir: 1_300_000,
        hyd_hose_high: 2_300_000,
        hyd_hose_low: 1_200_000,
        hyd_hose_to_box: 2_400_000,
        eps_motor: 3_900_000,
      },
      E,
    ),
  },
  toyotaCamry: {
    ...scale(VERNA, 1.25),
    ...box(
      {
        steering_box: 8_200_000,
        hyd_pump: 2_800_000,
        hyd_pump_repair: 4_100_000,
        hyd_reservoir: 1_600_000,
        hyd_hose_high: 2_800_000,
        hyd_hose_low: 1_500_000,
        hyd_hose_to_box: 2_900_000,
        eps_motor: 4_800_000,
      },
      E,
    ),
  },
  toyotaSuv: {
    ...scale(VERNA, 1.38),
    ...box(
      {
        steering_box: 8_800_000,
        hyd_pump: 3_000_000,
        hyd_pump_repair: 4_500_000,
        hyd_reservoir: 1_750_000,
        hyd_hose_high: 3_000_000,
        hyd_hose_low: 1_600_000,
        hyd_hose_to_box: 3_100_000,
        eps_motor: 5_200_000,
      },
      E,
    ),
  },
  toyotaPrado: {
    ...scale(VERNA, 1.65),
    ...box(
      {
        steering_box: 10_500_000,
        hyd_pump: 3_600_000,
        hyd_pump_repair: 5_400_000,
        hyd_reservoir: 2_100_000,
        hyd_hose_high: 3_600_000,
        hyd_hose_low: 1_900_000,
        hyd_hose_to_box: 3_700_000,
        eps_motor: 6_400_000,
      },
      E,
    ),
  },
  lexusSedan: {
    ...scale(VERNA, 1.55),
    ...box(
      {
        steering_box: 10_000_000,
        hyd_pump: 3_400_000,
        hyd_pump_repair: 5_100_000,
        hyd_reservoir: 2_000_000,
        hyd_hose_high: 3_400_000,
        hyd_hose_low: 1_800_000,
        hyd_hose_to_box: 3_500_000,
        eps_motor: 6_000_000,
      },
      E,
    ),
  },
  lexusSuv: {
    ...scale(VERNA, 1.75),
    ...box(
      {
        steering_box: 11_500_000,
        hyd_pump: 3_900_000,
        hyd_pump_repair: 5_800_000,
        hyd_reservoir: 2_300_000,
        hyd_hose_high: 3_900_000,
        hyd_hose_low: 2_100_000,
        hyd_hose_to_box: 4_000_000,
        eps_motor: 6_800_000,
      },
      E,
    ),
  },
  china: scale(L90, 1.65),
};

/** پکیج تعمیر کامل جلوبندی ۱۴۰۵ — تومان، به‌ازای هر خودرو */
const PACKAGE_1405: Record<string, RateCell> = {
  pride: r(2_660_000, U5),
  tiba: r(3_010_000, U5),
  saina: r(2_260_000, U5),
  quick: r(2_260_000, U5),
  rio: r(3_260_000, U5),
  mazda: r(2_860_000, U5),
  "405": r(3_140_000, U5),
  pars: r(3_140_000, U5),
  samand: r(3_140_000, U5),
  "samand-ef7": r(3_140_000, U5),
  "206": r(2_860_000, U5),
  "207": r(2_860_000, U5),
  rana: r(2_860_000, U5),
  dena: r(3_140_000, U5),
  "dena-plus": r(3_140_000, U5),
  l90: r(5_240_000, U5),
  sandro: r(5_240_000, U5),
  megane: r(13_650_000, U5),
  verna: r(7_200_000, E),
  accent: r(7_200_000, E),
  i20: r(7_400_000, E),
  elantra: r(8_100_000, E),
  avante: r(7_800_000, E),
  sonata: r(9_700_000, E),
  tucson: r(10_200_000, E),
  ix35: r(10_200_000, E),
  santafe: r(11_300_000, E),
  cerato: r(8_900_000, E),
  optima: r(9_600_000, E),
  sportage: r(10_200_000, E),
  sorento: r(11_300_000, E),
  yaris: r(7_800_000, E),
  corolla: r(8_400_000, E),
  camry: r(10_000_000, E),
  rav4: r(10_700_000, E),
  hilux: r(12_000_000, E),
  prado: r(12_600_000, E),
  landcruiser: r(14_700_000, E),
  "lexus-is": r(12_400_000, E),
  "lexus-es": r(13_100_000, E),
  "lexus-nx": r(13_500_000, E),
  "lexus-rx": r(14_200_000, E),
  "jac-s5": r(9_250_000, U5),
  "jac-j5": r(8_400_000, U5),
  arrizo5: r(9_700_000, U5),
  tiggo5: r(8_750_000, U5),
  x33: r(8_230_000, U5),
};

export const SOURCE_LABEL: Record<RateSource, string> = {
  "union-1404": "اتحادیه دی ۱۴۰۴",
  estimated: "برآورد به‌روز",
  "union-1405": "اتحادیه ۱۴۰۵",
};

export function getCar(carId: string): CarDef | undefined {
  return CARS.find((c) => c.id === carId);
}

export function getService(serviceId: string): ServiceDef | undefined {
  return SERVICES.find((s) => s.id === serviceId);
}

export function getRate(carId: string, serviceId: string): RateCell | undefined {
  if (serviceId === "full_front") return PACKAGE_1405[carId];
  const car = getCar(carId);
  if (!car) return undefined;
  return FAMILY_RATES[car.family]?.[serviceId];
}

export function servicesForCar(carId: string): { service: ServiceDef; rate: RateCell }[] {
  return SERVICES.flatMap((service) => {
    const rate = getRate(carId, service.id);
    return rate ? [{ service, rate }] : [];
  });
}

export const RATE_YEAR_NOTE =
  "پکیج تعمیر کامل خودروهای داخلی از نرخ‌نامه اتحادیه صنف تعمیرکاران خودرو تهران سال ۱۴۰۵ است. اجرت جزءبه‌جزء جلوبندی بر اساس جدول اتحادیه (۸ دی ۱۴۰۴) است. اجرت جعبه فرمان، پمپ و شلنگ هیدرولیک خودروهای داخلی از نرخ اتحادیه مکانیکی ۱۴۰۵ است. خودروهای کره‌ای و ژاپنی و ردیف‌های «برآورد» از نرخ ورنا با ضریب پیچیدگی به‌روز شده‌اند. مبالغ فقط دستمزد است و قطعه، مصرفی و مالیات را شامل نمی‌شود.";
