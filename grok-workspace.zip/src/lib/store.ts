import { create } from "zustand";
import { persist } from "zustand/middleware";
import { grandTotal, laborTotal } from "@/lib/calc";
import { getRate, getService, type RateSource } from "@/lib/rates";

export type MoneyUnit = "toman" | "rial";

export interface CartLine {
  id: string;
  serviceId?: string;
  name: string;
  qty: number;
  unitToman: number;
  source?: RateSource;
  custom?: boolean;
}

export interface SavedInvoice {
  id: string;
  createdAt: string;
  carId: string;
  carName: string;
  customerName: string;
  plate: string;
  lines: CartLine[];
  partsToman: number;
  discountPercent: number;
  vatEnabled: boolean;
  laborToman: number;
  totalToman: number;
}

interface EstimatorState {
  carId: string;
  query: string;
  category: string;
  unit: MoneyUnit;
  persianDigits: boolean;
  vatEnabled: boolean;
  shopName: string;
  shopPhone: string;
  shopAddress: string;
  customerName: string;
  plate: string;
  note: string;
  partsToman: number;
  discountPercent: number;
  lines: CartLine[];
  saved: SavedInvoice[];
  setCar: (carId: string) => void;
  setQuery: (q: string) => void;
  setCategory: (c: string) => void;
  setUnit: (u: MoneyUnit) => void;
  setPersianDigits: (v: boolean) => void;
  setVatEnabled: (v: boolean) => void;
  setShop: (p: Partial<Pick<EstimatorState, "shopName" | "shopPhone" | "shopAddress">>) => void;
  setCustomer: (p: Partial<Pick<EstimatorState, "customerName" | "plate" | "note">>) => void;
  setParts: (n: number) => void;
  setDiscount: (n: number) => void;
  addService: (serviceId: string) => void;
  addServices: (serviceIds: string[]) => void;
  setQty: (lineId: string, qty: number) => void;
  removeLine: (lineId: string) => void;
  addCustom: (name: string, unitToman: number) => void;
  clearCart: () => void;
  saveInvoice: (carName: string) => SavedInvoice;
  deleteSaved: (id: string) => void;
  loadSaved: (id: string) => void;
}

function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function repriced(lines: CartLine[], carId: string): CartLine[] {
  return lines.flatMap((line) => {
    if (line.custom || !line.serviceId) return [line];
    const rate = getRate(carId, line.serviceId);
    if (!rate) return [];
    return [{ ...line, unitToman: rate.toman, source: rate.source }];
  });
}

function makeLine(carId: string, serviceId: string): CartLine | null {
  const service = getService(serviceId);
  const rate = getRate(carId, serviceId);
  if (!service || !rate) return null;
  const qty =
    service.qtyKind === "perSide" || service.qtyKind === "perUnit"
      ? Math.min(2, service.maxQty)
      : 1;
  return {
    id: uid(),
    serviceId,
    name: service.name,
    qty,
    unitToman: rate.toman,
    source: rate.source,
  };
}

export const useEstimator = create<EstimatorState>()(
  persist(
    (set, get) => ({
      carId: "pride",
      query: "",
      category: "all",
      unit: "toman",
      persianDigits: true,
      vatEnabled: false,
      shopName: "غرب تکنیک",
      shopPhone: "",
      shopAddress: "تهران",
      customerName: "",
      plate: "",
      note: "",
      partsToman: 0,
      discountPercent: 0,
      lines: [],
      saved: [],
      setCar: (carId) =>
        set({
          carId,
          lines: repriced(get().lines, carId),
        }),
      setQuery: (query) => set({ query }),
      setCategory: (category) => set({ category }),
      setUnit: (unit) => set({ unit }),
      setPersianDigits: (persianDigits) => set({ persianDigits }),
      setVatEnabled: (vatEnabled) => set({ vatEnabled }),
      setShop: (p) => set(p),
      setCustomer: (p) => set(p),
      setParts: (partsToman) => set({ partsToman: Math.max(0, partsToman) }),
      setDiscount: (discountPercent) =>
        set({ discountPercent: Math.min(100, Math.max(0, discountPercent)) }),
      addService: (serviceId) => {
        const { carId, lines } = get();
        const service = getService(serviceId);
        const existing = lines.find((l) => l.serviceId === serviceId);
        if (existing && service) {
          const next = Math.min(existing.qty + 1, service.maxQty);
          set({
            lines: lines.map((l) => (l.id === existing.id ? { ...l, qty: next } : l)),
          });
          return;
        }
        const line = makeLine(carId, serviceId);
        if (!line) return;
        set({ lines: [...lines, line] });
      },
      addServices: (serviceIds) => {
        const { carId } = get();
        let lines = [...get().lines];
        for (const serviceId of serviceIds) {
          if (lines.some((l) => l.serviceId === serviceId)) continue;
          const line = makeLine(carId, serviceId);
          if (line) lines = [...lines, line];
        }
        set({ lines });
      },
      setQty: (lineId, qty) => {
        set({
          lines: get().lines.map((l) => {
            if (l.id !== lineId) return l;
            const max = l.custom ? 20 : (getService(l.serviceId ?? "")?.maxQty ?? 10);
            return { ...l, qty: Math.max(1, Math.min(max, qty)) };
          }),
        });
      },
      removeLine: (lineId) => set({ lines: get().lines.filter((l) => l.id !== lineId) }),
      addCustom: (name, unitToman) => {
        const trimmed = name.trim();
        if (!trimmed || unitToman <= 0) return;
        set({
          lines: [
            ...get().lines,
            {
              id: uid(),
              name: trimmed,
              qty: 1,
              unitToman,
              custom: true,
            },
          ],
        });
      },
      clearCart: () => set({ lines: [], partsToman: 0, discountPercent: 0 }),
      saveInvoice: (carName) => {
        const s = get();
        const labor = laborTotal(s.lines);
        const total = grandTotal(s.lines, s.partsToman, s.discountPercent, s.vatEnabled);
        const invoice: SavedInvoice = {
          id: uid(),
          createdAt: new Date().toISOString(),
          carId: s.carId,
          carName,
          customerName: s.customerName,
          plate: s.plate,
          lines: s.lines,
          partsToman: s.partsToman,
          discountPercent: s.discountPercent,
          vatEnabled: s.vatEnabled,
          laborToman: labor,
          totalToman: total,
        };
        set({ saved: [invoice, ...s.saved].slice(0, 40) });
        return invoice;
      },
      deleteSaved: (id) => set({ saved: get().saved.filter((x) => x.id !== id) }),
      loadSaved: (id) => {
        const inv = get().saved.find((x) => x.id === id);
        if (!inv) return;
        set({
          carId: inv.carId,
          lines: inv.lines,
          partsToman: inv.partsToman,
          discountPercent: inv.discountPercent,
          vatEnabled: inv.vatEnabled ?? false,
          customerName: inv.customerName,
          plate: inv.plate,
        });
      },
    }),
    {
      name: "jelobandi-estimator-v2",
      skipHydration: true,
      partialize: (s) => ({
        carId: s.carId,
        unit: s.unit,
        persianDigits: s.persianDigits,
        vatEnabled: s.vatEnabled,
        shopName: s.shopName,
        shopPhone: s.shopPhone,
        shopAddress: s.shopAddress,
        customerName: s.customerName,
        plate: s.plate,
        note: s.note,
        partsToman: s.partsToman,
        discountPercent: s.discountPercent,
        lines: s.lines,
        saved: s.saved,
      }),
    },
  ),
);
