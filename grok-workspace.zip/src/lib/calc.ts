export const VAT_RATE = 0.09;

export interface PricedLine {
  unitToman: number;
  qty: number;
}

export function laborTotal(lines: PricedLine[]): number {
  return lines.reduce((sum, line) => sum + line.unitToman * line.qty, 0);
}

export function afterDiscount(
  laborToman: number,
  partsToman: number,
  discountPercent: number,
): number {
  const sub = laborToman + Math.max(0, partsToman);
  const cut = Math.min(100, Math.max(0, discountPercent)) / 100;
  return Math.round(sub * (1 - cut));
}

export function grandTotal(
  lines: PricedLine[],
  partsToman: number,
  discountPercent: number,
  vatEnabled: boolean,
): number {
  const after = afterDiscount(laborTotal(lines), partsToman, discountPercent);
  return vatEnabled ? Math.round(after * (1 + VAT_RATE)) : after;
}

export function vatAmount(
  lines: PricedLine[],
  partsToman: number,
  discountPercent: number,
  vatEnabled: boolean,
): number {
  const after = afterDiscount(laborTotal(lines), partsToman, discountPercent);
  return vatEnabled ? grandTotal(lines, partsToman, discountPercent, true) - after : 0;
}

export function discountAmount(
  laborToman: number,
  partsToman: number,
  discountPercent: number,
): number {
  const sub = laborToman + Math.max(0, partsToman);
  return sub - afterDiscount(laborToman, partsToman, discountPercent);
}
