export interface Symptom {
  id: string;
  name: string;
  hint: string;
  serviceIds: string[];
}

export const SYMPTOMS: Symptom[] = [
  {
    id: "full",
    name: "سرویس کامل",
    hint: "دستمزد پکیج تعمیر کامل جلوبندی طبق نرخ ۱۴۰۵",
    serviceIds: ["full_front"],
  },
  {
    id: "knock",
    name: "صدای تق‌تق از جلو",
    hint: "معمولاً سیبک، طبق یا بوش معیوب است",
    serviceIds: ["tie_rod", "lower_ball", "control_arm", "arm_bush"],
  },
  {
    id: "bump",
    name: "ضربه در دست‌انداز",
    hint: "بوش موج‌گیر، کمک‌فنر یا طبق را بررسی کنید",
    serviceIds: ["sway_bush", "sway_bar", "front_shock", "arm_bush"],
  },
  {
    id: "pull",
    name: "کشیدن به یک سمت",
    hint: "سیبک فرمان، طبق و میزان فرمان",
    serviceIds: ["align_machine", "tie_rod", "control_arm"],
  },
  {
    id: "shake",
    name: "لرزش فرمان",
    hint: "بلبرینگ چرخ، قرقری یا میزان فرمان",
    serviceIds: ["align_machine", "knuckle_bearing", "inner_tie", "front_shock"],
  },
  {
    id: "soft",
    name: "نرمی یا روغن‌ریزی کمک",
    hint: "کمک‌فنر جلو باید تعویض شود",
    serviceIds: ["front_shock"],
  },
  {
    id: "play",
    name: "بازی غربیلک فرمان",
    hint: "جعبه فرمان، قرقری، چهارشاخه یا گردگیر فرمان",
    serviceIds: ["steering_box", "inner_tie", "steering_cross", "bellows", "wheel_adj"],
  },
  {
    id: "hyd",
    name: "سختی یا نشتی فرمان",
    hint: "پمپ، شلنگ یا جعبه فرمان هیدرولیک را بررسی کنید",
    serviceIds: ["steering_box", "hyd_pump", "hyd_hose_high", "hyd_reservoir"],
  },
  {
    id: "tire",
    name: "سایش نامنظم لاستیک",
    hint: "طبق، سیبک و میزان فرمان با دستگاه",
    serviceIds: ["align_machine", "control_arm", "tie_rod"],
  },
];
