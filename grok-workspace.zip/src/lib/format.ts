const ONES = ["", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه"];
const TEENS = [
  "ده",
  "یازده",
  "دوازده",
  "سیزده",
  "چهارده",
  "پانزده",
  "شانزده",
  "هفده",
  "هجده",
  "نوزده",
];
const TENS = ["", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"];
const HUNDREDS = [
  "",
  "یکصد",
  "دویست",
  "سیصد",
  "چهارصد",
  "پانصد",
  "ششصد",
  "هفتصد",
  "هشتصد",
  "نهصد",
];
const SCALES = ["", "هزار", "میلیون", "میلیارد", "هزار میلیارد"];

function chunkToWords(n: number): string {
  const h = Math.floor(n / 100);
  const rest = n % 100;
  const parts: string[] = [];
  if (h) parts.push(HUNDREDS[h] ?? "");
  if (rest >= 10 && rest < 20) {
    parts.push(TEENS[rest - 10] ?? "");
  } else {
    const t = Math.floor(rest / 10);
    const o = rest % 10;
    if (t) parts.push(TENS[t] ?? "");
    if (o) parts.push(ONES[o] ?? "");
  }
  return parts.filter(Boolean).join(" و ");
}

export function tomanToWords(toman: number): string {
  if (toman === 0) return "صفر تومان";
  if (toman < 0) return "نامعتبر";
  const whole = Math.round(toman);
  const parts: string[] = [];
  let remaining = whole;
  let scale = 0;
  while (remaining > 0 && scale < SCALES.length) {
    const chunk = remaining % 1000;
    if (chunk) {
      const words = chunkToWords(chunk);
      const scaleName = SCALES[scale];
      parts.unshift(scaleName ? `${words} ${scaleName}` : words);
    }
    remaining = Math.floor(remaining / 1000);
    scale += 1;
  }
  return `${parts.join(" و ")} تومان`;
}

export function formatToman(toman: number, persian = true): string {
  const formatted = new Intl.NumberFormat(persian ? "fa-IR" : "en-US").format(
    Math.round(toman),
  );
  return persian ? `${formatted} تومان` : `${formatted} Toman`;
}

export function formatRial(toman: number, persian = true): string {
  const formatted = new Intl.NumberFormat(persian ? "fa-IR" : "en-US").format(
    Math.round(toman * 10),
  );
  return persian ? `${formatted} ریال` : `${formatted} Rial`;
}

export function formatMoney(
  toman: number,
  unit: "toman" | "rial",
  persian = true,
): string {
  return unit === "rial" ? formatRial(toman, persian) : formatToman(toman, persian);
}

export function formatNumber(n: number, persian = true): string {
  return new Intl.NumberFormat(persian ? "fa-IR" : "en-US").format(n);
}

const JALALI_MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];

export function gregorianToJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
  let jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days =
    365 * gy +
    Math.floor((gy2 + 3) / 4) -
    Math.floor((gy2 + 99) / 100) +
    Math.floor((gy2 + 399) / 400) -
    80 +
    gd +
    (g_d_m[gm - 1] ?? 0);
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return [jy, jm, jd];
}

export function formatJalali(date = new Date(), persian = true): string {
  const [jy, jm, jd] = gregorianToJalali(
    date.getFullYear(),
    date.getMonth() + 1,
    date.getDate(),
  );
  const month = JALALI_MONTHS[jm - 1] ?? "";
  const fa = "۰۱۲۳۴۵۶۷۸۹";
  const toDigits = (n: number) =>
    persian ? String(n).replace(/\d/g, (d) => fa[Number(d)] ?? d) : String(n);
  return `${toDigits(jd)} ${month} ${toDigits(jy)}`;
}
