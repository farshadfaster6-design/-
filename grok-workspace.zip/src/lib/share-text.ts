import { afterDiscount, discountAmount, laborTotal, vatAmount } from "@/lib/calc";
import { formatJalali, formatMoney, tomanToWords } from "@/lib/format";
import type { MoneyUnit } from "@/lib/store";
import type { CartLine } from "@/lib/store";

export function invoiceShareText(opts: {
  shopName: string;
  carName: string;
  customerName: string;
  plate: string;
  lines: CartLine[];
  partsToman: number;
  discountPercent: number;
  vatEnabled: boolean;
  unit: MoneyUnit;
  persian: boolean;
}): string {
  const money = (n: number) => formatMoney(n, opts.unit, opts.persian);
  const labor = laborTotal(opts.lines);
  const after = afterDiscount(labor, opts.partsToman, opts.discountPercent);
  const vat = vatAmount(opts.lines, opts.partsToman, opts.discountPercent, opts.vatEnabled);
  const total = after + vat;
  const rows = opts.lines
    .map((line) => `• ${line.name} × ${line.qty} — ${money(line.unitToman * line.qty)}`)
    .join("\n");
  const who = [opts.customerName, opts.plate].filter(Boolean).join(" · ");
  return [
    opts.shopName || "غرب تکنیک",
    `تاریخ: ${formatJalali(new Date(), opts.persian)}`,
    `خودرو: ${opts.carName}${who ? ` | ${who}` : ""}`,
    "",
    rows,
    "",
    `جمع اجرت: ${money(labor)}`,
    opts.partsToman > 0 ? `قطعات: ${money(opts.partsToman)}` : "",
    opts.discountPercent > 0
      ? `تخفیف: ${money(discountAmount(labor, opts.partsToman, opts.discountPercent))}`
      : "",
    opts.vatEnabled ? `مالیات ارزش افزوده ۹٪: ${money(vat)}` : "",
    `قابل پرداخت: ${money(total)}`,
    tomanToWords(total),
    "",
    "نرخ اتحادیه صنف تعمیرکاران خودرو تهران — فقط دستمزد",
  ]
    .filter((line) => line !== "")
    .join("\n");
}
