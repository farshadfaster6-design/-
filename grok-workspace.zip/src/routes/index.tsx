import { createFileRoute } from "@tanstack/react-router";
import { Estimator } from "@/components/estimator";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Estimator />;
}
