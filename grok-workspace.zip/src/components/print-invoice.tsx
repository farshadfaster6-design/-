import { afterDiscount, discountAmount, grandTotal, laborTotal, vatAmount } from "@/lib/calc";
import { formatJalali, formatMoney, formatNumber, tomanToWords } from "@/lib/format";
import { SOURCE_LABEL } from "@/lib/rates";
import type { CartLine } from "@/lib/store";
import { IranPlatePreview } from "@/components/iran-plate";

interface PrintInvoiceProps {
  shopName: string;
  shopPhone: string;
  shopAddress: string;
  customerName: string;
  plate: string;
  note: string;
  carName: string;
  lines: CartLine[];
  partsToman: number;
  discountPercent: number;
  vatEnabled: boolean;
  unit: "toman" | "rial";
  persian: boolean;
}

export function PrintInvoice({
  shopName,
  shopPhone,
  shopAddress,
  customerName,
  plate,
  note,
  carName,
  lines,
  partsToman,
  discountPercent,
  vatEnabled,
  unit,
  persian,
}: PrintInvoiceProps) {
  const labor = laborTotal(lines);
  const disc = discountAmount(labor, partsToman, discountPercent);
  const after = afterDiscount(labor, partsToman, discountPercent);
  const vat = vatAmount(lines, partsToman, discountPercent, vatEnabled);
  const total = grandTotal(lines, partsToman, discountPercent, vatEnabled);
  const money = (n: number) => formatMoney(n, unit, persian);

  return (
    <section className="print-sheet hidden bg-surface text-ink">
      <header className="mb-6 flex items-start justify-between border-b-2 border-accent pb-4">
        <div>
          <p className="text-xs text-muted">فاکتور اجرت جلوبندی · غرب تکنیک</p>
          <h1 className="mt-1 text-xl font-semibold">{shopName || "غرب تکنیک"}</h1>
          <p className="mt-1 text-sm text-muted">
            {shopAddress}
            {shopPhone ? ` · ${shopPhone}` : ""}
          </p>
        </div>
        <div className="text-left text-sm">
          <p>تاریخ: {formatJalali(new Date(), persian)}</p>
          <p className="mt-1 text-accent">اتحادیه صنف تعمیرکاران خودرو</p>
        </div>
      </header>

      <div className="mb-4 grid grid-cols-3 gap-3 text-sm">
        <div>
          <p className="text-xs text-muted">مشتری</p>
          <p className="font-medium">{customerName || "—"}</p>
        </div>
        <div>
          <p className="text-xs text-muted">پلاک</p>
          <p className="font-medium">
            <IranPlatePreview value={plate} />
          </p>
        </div>
        <div>
          <p className="text-xs text-muted">خودرو</p>
          <p className="font-medium">{carName}</p>
        </div>
      </div>

      <table className="w-full border-collapse text-sm">
        <thead>
          <tr className="border-b border-line text-muted">
            <th className="py-2 text-right font-medium">شرح خدمات</th>
            <th className="py-2 text-center font-medium">تعداد</th>
            <th className="py-2 text-left font-medium">فی</th>
            <th className="py-2 text-left font-medium">مبلغ</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((line) => (
            <tr key={line.id} className="border-b border-line/60">
              <td className="py-2">
                {line.name}
                {line.source === "estimated" ? (
                  <span className="mr-1 text-xs text-faint">({SOURCE_LABEL.estimated})</span>
                ) : null}
              </td>
              <td className="py-2 text-center tabular-nums">{formatNumber(line.qty, persian)}</td>
              <td className="py-2 text-left tabular-nums">{money(line.unitToman)}</td>
              <td className="py-2 text-left tabular-nums font-medium">
                {money(line.unitToman * line.qty)}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="mt-6 mr-auto max-w-sm text-sm">
        <div className="flex justify-between py-1">
          <span className="text-muted">جمع اجرت</span>
          <span className="tabular-nums">{money(labor)}</span>
        </div>
        {partsToman > 0 ? (
          <div className="flex justify-between py-1">
            <span className="text-muted">قطعات</span>
            <span className="tabular-nums">{money(partsToman)}</span>
          </div>
        ) : null}
        {discountPercent > 0 ? (
          <div className="flex justify-between py-1">
            <span className="text-muted">تخفیف {formatNumber(discountPercent, persian)}٪</span>
            <span className="tabular-nums">{money(disc)}</span>
          </div>
        ) : null}
        {vatEnabled ? (
          <>
            <div className="flex justify-between py-1">
              <span className="text-muted">پس از تخفیف</span>
              <span className="tabular-nums">{money(after)}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-muted">مالیات ارزش افزوده ۹٪</span>
              <span className="tabular-nums">{money(vat)}</span>
            </div>
          </>
        ) : null}
        <div className="mt-2 flex justify-between border-t border-line pt-2 text-base font-semibold">
          <span>قابل پرداخت</span>
          <span className="tabular-nums">{money(total)}</span>
        </div>
        <p className="mt-2 text-xs text-muted">{tomanToWords(total)}</p>
      </div>

      {note ? <p className="mt-6 text-sm text-muted">توضیحات: {note}</p> : null}

      <p className="mt-8 text-xs leading-6 text-faint">
        اجرت بر اساس نرخ اتحادیه صنف تعمیرکاران خودرو تهران محاسبه شده است. مبلغ قطعات در صورت درج،
        جدا از دستمزد است. نرخ‌های برآوردی با علامت مشخص شده‌اند. این فاکتور جنبه اطلاع‌رسانی دارد و
        جایگزین نرخ‌نامه ممهور اتحادیه نیست.
      </p>

      <div className="mt-10 grid grid-cols-2 gap-8 text-sm text-muted">
        <div>
          <p>امضای مشتری</p>
          <div className="mt-8 border-b border-line" />
        </div>
        <div>
          <p>مهر و امضای تعمیرگاه</p>
          <div className="mt-8 border-b border-line" />
        </div>
      </div>
    </section>
  );
}
