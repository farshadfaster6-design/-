import { cn } from "@/lib/utils";

const LETTERS = ["ب", "ج", "د", "س", "ص", "ط", "ع", "ق", "ل", "م", "ن", "و", "ه", "ی", "ت"] as const;

function joinPlate(parts: { left: string; letter: string; mid: string; province: string }): string {
  const body = `${parts.left}${parts.letter}${parts.mid}`;
  if (!body && !parts.province) return "";
  return parts.province ? `${body}-${parts.province}` : body;
}

export function IranPlateInput({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const [left, rest] = value.split("-");
  const body = left ?? "";
  const province = rest ?? "";
  const letterIdx = [...body].findIndex((ch) => Number.isNaN(Number(ch)));
  const numLeft = letterIdx === -1 ? body.slice(0, 2) : body.slice(0, letterIdx);
  const letter = letterIdx === -1 ? "" : body.slice(letterIdx, letterIdx + 1);
  const mid = letterIdx === -1 ? "" : body.slice(letterIdx + 1).replace(/\D/g, "").slice(0, 3);

  function emit(next: { left?: string; letter?: string; mid?: string; province?: string }) {
    onChange(
      joinPlate({
        left: (next.left ?? numLeft).replace(/\D/g, "").slice(0, 2),
        letter: next.letter ?? letter,
        mid: (next.mid ?? mid).replace(/\D/g, "").slice(0, 3),
        province: (next.province ?? province).replace(/\D/g, "").slice(0, 2),
      }),
    );
  }

  return (
    <div
      dir="ltr"
      className="flex h-11 overflow-hidden rounded-md border border-ink/20 bg-surface text-ink"
    >
      <Field
        value={numLeft}
        onChange={(v) => emit({ left: v })}
        maxLength={2}
        ariaLabel="دو رقم سمت چپ پلاک"
        className="w-12"
      />
      <select
        aria-label="حرف پلاک"
        value={letter}
        onChange={(e) => emit({ letter: e.target.value })}
        className="w-14 border-x border-ink/15 bg-surface text-center text-sm font-semibold outline-none"
      >
        <option value="">—</option>
        {LETTERS.map((l) => (
          <option key={l} value={l}>
            {l}
          </option>
        ))}
      </select>
      <Field
        value={mid}
        onChange={(v) => emit({ mid: v })}
        maxLength={3}
        ariaLabel="سه رقم پلاک"
        className="w-16"
      />
      <div className="flex w-12 shrink-0 flex-col items-center justify-center bg-plate-blue text-xs leading-none text-accent-fg">
        <span className="font-semibold">ایران</span>
        <span className="mt-0.5 tracking-wide">I.R.</span>
      </div>
      <Field
        value={province}
        onChange={(v) => emit({ province: v })}
        maxLength={2}
        ariaLabel="کد استان"
        className="w-12"
      />
    </div>
  );
}

function Field({
  value,
  onChange,
  maxLength,
  ariaLabel,
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  maxLength: number;
  ariaLabel: string;
  className?: string;
}) {
  return (
    <input
      inputMode="numeric"
      maxLength={maxLength}
      aria-label={ariaLabel}
      value={value}
      onChange={(e) => onChange(e.target.value.replace(/\D/g, "").slice(0, maxLength))}
      className={cn(
        "h-full bg-transparent text-center text-sm font-semibold tabular-nums outline-none",
        className,
      )}
    />
  );
}

export function IranPlatePreview({ value }: { value: string }) {
  if (!value) return <span className="text-muted">—</span>;
  return (
    <span className="font-medium tracking-wide" dir="ltr">
      {value}
    </span>
  );
}
