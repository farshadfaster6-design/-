import { useEffect, useMemo, useState, type FormEvent, type ReactNode } from "react";
import {
  Check,
  Copy,
  Minus,
  Plus,
  Printer,
  Save,
  Search,
  Settings2,
  Trash2,
  X,
} from "lucide-react";
import { toast } from "sonner";
import { IranPlateInput } from "@/components/iran-plate";
import { PrintInvoice } from "@/components/print-invoice";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  discountAmount,
  grandTotal,
  laborTotal,
  vatAmount,
} from "@/lib/calc";
import {
  formatJalali,
  formatMoney,
  formatNumber,
  tomanToWords,
} from "@/lib/format";
import {
  BRANDS,
  CARS,
  CATEGORIES,
  RATE_YEAR_NOTE,
  SERVICES,
  SOURCE_LABEL,
  getCar,
  getRate,
  servicesForCar,
  type BrandId,
  type CategoryId,
} from "@/lib/rates";
import { invoiceShareText } from "@/lib/share-text";
import { useEstimator } from "@/lib/store";
import { SYMPTOMS } from "@/lib/symptoms";
import { cn } from "@/lib/utils";

type Tab = "estimate" | "table" | "saved";

function UnionSeal() {
  return (
    <svg viewBox="0 0 64 64" className="size-12 shrink-0" aria-hidden="true">
      <circle cx="32" cy="32" r="30" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="32" cy="32" r="24" fill="none" stroke="currentColor" strokeWidth="0.75" />
      <path
        d="M16 38h32M20 38c0-6 4-12 12-14 8 2 12 8 12 14"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
      />
      <circle cx="22" cy="39" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.6" />
      <circle cx="42" cy="39" r="3.2" fill="none" stroke="currentColor" strokeWidth="1.6" />
    </svg>
  );
}

export function Estimator() {
  const [tab, setTab] = useState<Tab>("estimate");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [customName, setCustomName] = useState("");
  const [customPrice, setCustomPrice] = useState("");
  const [invoiceOpen, setInvoiceOpen] = useState(false);
  const [brandFilter, setBrandFilter] = useState<BrandId | "all">("saipa");
  const [symptomId, setSymptomId] = useState<string | null>(null);

  useEffect(() => {
    void Promise.resolve(useEstimator.persist.rehydrate()).then(() => {
      const state = useEstimator.getState();
      const next = getCar(state.carId);
      if (next) setBrandFilter(next.brand);
      if (!state.shopName || state.shopName === "تعمیرگاه جلوبندی") {
        state.setShop({ shopName: "غرب تکنیک" });
      }
    });
  }, []);

  const carId = useEstimator((s) => s.carId);
  const query = useEstimator((s) => s.query);
  const category = useEstimator((s) => s.category);
  const unit = useEstimator((s) => s.unit);
  const persian = useEstimator((s) => s.persianDigits);
  const vatEnabled = useEstimator((s) => s.vatEnabled);
  const lines = useEstimator((s) => s.lines);
  const partsToman = useEstimator((s) => s.partsToman);
  const discountPercent = useEstimator((s) => s.discountPercent);
  const shopName = useEstimator((s) => s.shopName);
  const shopPhone = useEstimator((s) => s.shopPhone);
  const shopAddress = useEstimator((s) => s.shopAddress);
  const customerName = useEstimator((s) => s.customerName);
  const plate = useEstimator((s) => s.plate);
  const note = useEstimator((s) => s.note);
  const saved = useEstimator((s) => s.saved);

  const setCar = useEstimator((s) => s.setCar);
  const setQuery = useEstimator((s) => s.setQuery);
  const setCategory = useEstimator((s) => s.setCategory);
  const setUnit = useEstimator((s) => s.setUnit);
  const setPersianDigits = useEstimator((s) => s.setPersianDigits);
  const setVatEnabled = useEstimator((s) => s.setVatEnabled);
  const addService = useEstimator((s) => s.addService);
  const addServices = useEstimator((s) => s.addServices);
  const setQty = useEstimator((s) => s.setQty);
  const removeLine = useEstimator((s) => s.removeLine);
  const addCustom = useEstimator((s) => s.addCustom);
  const clearCart = useEstimator((s) => s.clearCart);
  const setParts = useEstimator((s) => s.setParts);
  const setDiscount = useEstimator((s) => s.setDiscount);
  const setShop = useEstimator((s) => s.setShop);
  const setCustomer = useEstimator((s) => s.setCustomer);
  const saveInvoice = useEstimator((s) => s.saveInvoice);
  const deleteSaved = useEstimator((s) => s.deleteSaved);
  const loadSaved = useEstimator((s) => s.loadSaved);

  const car = getCar(carId) ?? CARS[0];
  const carName = car?.name ?? "پراید";
  const money = (n: number) => formatMoney(n, unit, persian);
  const labor = laborTotal(lines);
  const total = grandTotal(lines, partsToman, discountPercent, vatEnabled);
  const vat = vatAmount(lines, partsToman, discountPercent, vatEnabled);
  const disc = discountAmount(labor, partsToman, discountPercent);
  const pkg = getRate(carId, "full_front");
  const symptom = SYMPTOMS.find((s) => s.id === symptomId) ?? null;
  const highlight = new Set(symptom?.serviceIds ?? []);
  const hasPackage = lines.some((l) => l.serviceId === "full_front");
  const hasOther = lines.some((l) => l.serviceId && l.serviceId !== "full_front" && !l.custom);

  const catalog = useMemo(() => {
    const q = query.trim();
    return servicesForCar(carId).filter(({ service }) => {
      if (category !== "all" && service.category !== category) return false;
      if (highlight.size && !q && category === "all" && !highlight.has(service.id)) {
        /* still show all — highlight only */
      }
      if (!q) return true;
      return service.name.includes(q);
    });
  }, [carId, category, query, highlight.size]);

  const grouped = useMemo(() => {
    const map = new Map<CategoryId, typeof catalog>();
    for (const item of catalog) {
      const list = map.get(item.service.category) ?? [];
      list.push(item);
      map.set(item.service.category, list);
    }
    return CATEGORIES.filter((c) => map.has(c.id)).map((c) => ({
      ...c,
      items: map.get(c.id) ?? [],
    }));
  }, [catalog]);

  const brandCars = CARS.filter((c) => brandFilter === "all" || c.brand === brandFilter);

  function handlePrint() {
    window.print();
  }

  function handleSave() {
    saveInvoice(carName);
    toast.success("فاکتور ذخیره شد");
    setTab("saved");
    setInvoiceOpen(false);
  }

  async function handleCopy() {
    const text = invoiceShareText({
      shopName,
      carName,
      customerName,
      plate,
      lines,
      partsToman,
      discountPercent,
      vatEnabled,
      unit,
      persian,
    });
    try {
      await navigator.clipboard.writeText(text);
      toast.success("متن فاکتور کپی شد");
    } catch {
      toast.error("کپی انجام نشد");
    }
  }

  function submitCustom(e: FormEvent) {
    e.preventDefault();
    const n = Number(customPrice.replace(/[^\d.]/g, ""));
    addCustom(customName, unit === "rial" ? n / 10 : n);
    setCustomName("");
    setCustomPrice("");
  }

  function pickCar(id: string) {
    const next = getCar(id);
    if (next) setBrandFilter(next.brand);
    setCar(id);
  }

  function pickBrand(id: BrandId | "all") {
    setBrandFilter(id);
    if (id === "all") return;
    const current = getCar(carId);
    if (current?.brand === id) return;
    const first = CARS.find((c) => c.brand === id);
    if (first) setCar(first.id);
  }

  const invoiceProps = {
    customerName,
    plate,
    note,
    carName,
    lines,
    partsToman,
    discountPercent,
    vatEnabled,
    unit,
    persian,
    money,
    labor,
    total,
    vat,
    disc,
    onQty: setQty,
    onRemove: removeLine,
    onCustomName: setCustomName,
    onCustomPrice: setCustomPrice,
    customName,
    customPrice,
    onCustomSubmit: submitCustom,
    onParts: setParts,
    onDiscount: setDiscount,
    onCustomer: setCustomer,
    onPrint: handlePrint,
    onSave: handleSave,
    onCopy: handleCopy,
    onClear: clearCart,
    hasPackage,
    hasOther,
  };

  return (
    <div className="min-h-svh overflow-x-hidden bg-bg">
      <header className="no-print sticky top-0 z-20 border-b border-line/80 bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <div className="text-accent">
            <UnionSeal />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-lg font-semibold tracking-tight md:text-xl">
                نرخ‌نامه جلوبندی خودرو
              </h1>
              <Badge>۱۴۰۵ · {formatJalali(new Date(), persian)}</Badge>
            </div>
            <p className="truncate text-sm font-semibold text-accent">غرب تکنیک</p>
            <p className="truncate text-xs text-muted">
              اجرت مصوب اتحادیه صنف تعمیرکاران خودرو تهران
            </p>
          </div>
          <Button
            variant="outline"
            size="icon"
            aria-label="تنظیمات تعمیرگاه"
            onClick={() => setSettingsOpen((v) => !v)}
          >
            <Settings2 />
          </Button>
        </div>

        {settingsOpen ? (
          <div className="mx-auto grid max-w-6xl gap-3 border-t border-line px-4 py-4 md:grid-cols-3">
            <div className="space-y-1">
              <Label htmlFor="shop-name">نام تعمیرگاه</Label>
              <Input
                id="shop-name"
                value={shopName}
                onChange={(e) => setShop({ shopName: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="shop-phone">تلفن</Label>
              <Input
                id="shop-phone"
                value={shopPhone}
                dir="ltr"
                className="text-right"
                onChange={(e) => setShop({ shopPhone: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="shop-addr">آدرس</Label>
              <Input
                id="shop-addr"
                value={shopAddress}
                onChange={(e) => setShop({ shopAddress: e.target.value })}
              />
            </div>
            <div className="flex flex-wrap items-end gap-2 md:col-span-3">
              <Toggle
                on={unit === "toman"}
                onClick={() => setUnit("toman")}
                label="تومان"
              />
              <Toggle
                on={unit === "rial"}
                onClick={() => setUnit("rial")}
                label="ریال"
              />
              <Toggle
                on={persian}
                onClick={() => setPersianDigits(!persian)}
                label="اعداد فارسی"
              />
              <Toggle
                on={vatEnabled}
                onClick={() => setVatEnabled(!vatEnabled)}
                label="مالیات ۹٪"
              />
            </div>
          </div>
        ) : null}

        <nav className="mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 pb-2">
          {(
            [
              ["estimate", "برآورد اجرت"],
              ["table", "جدول نرخ‌ها"],
              ["saved", "فاکتورهای ذخیره‌شده"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={cn(
                "h-11 shrink-0 rounded-md px-3 text-sm font-medium transition-opacity duration-150",
                tab === id ? "bg-accent text-accent-fg" : "text-muted hover:bg-surface-2",
              )}
            >
              {label}
              {id === "saved" && saved.length > 0
                ? ` (${formatNumber(saved.length, persian)})`
                : ""}
            </button>
          ))}
        </nav>
      </header>

      <main className="relative mx-auto min-w-0 max-w-6xl px-4 py-5 pb-28 lg:pb-5">
        {tab === "estimate" ? (
          <div className="grid min-w-0 gap-5 lg:grid-cols-3">
            <section className="no-print min-w-0 space-y-4 lg:col-span-2">
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted">انتخاب خودرو</p>
                <div className="flex flex-wrap gap-2">
                  <FilterChip
                    active={brandFilter === "all"}
                    onClick={() => pickBrand("all")}
                  >
                    همه
                  </FilterChip>
                  {BRANDS.map((b) => (
                    <FilterChip
                      key={b.id}
                      active={brandFilter === b.id}
                      onClick={() => pickBrand(b.id)}
                    >
                      {b.name}
                    </FilterChip>
                  ))}
                </div>
                <div className="max-w-full overflow-x-auto pb-1">
                  <div className="flex w-max gap-2 md:w-full md:flex-wrap">
                    {brandCars.map((item) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => pickCar(item.id)}
                        className={cn(
                          "h-11 shrink-0 rounded-lg px-3 text-sm font-medium ring-1 transition-opacity duration-150",
                          carId === item.id
                            ? "bg-accent text-accent-fg ring-accent"
                            : "bg-surface text-ink ring-line hover:bg-surface-2",
                        )}
                      >
                        {item.name}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {pkg ? (
                <div className="flex flex-wrap items-center gap-3 rounded-xl border border-line bg-surface px-4 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium text-muted">
                      تعمیر کامل جلوبندی · {carName}
                    </p>
                    <p className="mt-1 text-2xl font-semibold tabular-nums tracking-tight">
                      {money(pkg.toman)}
                    </p>
                    <p className="mt-1 text-xs text-faint">
                      نرخ مصوب اتحادیه ۱۴۰۵ · فقط دستمزد، بدون قطعه
                    </p>
                  </div>
                  <Button onClick={() => addService("full_front")}>
                    <Plus />
                    افزودن به فاکتور
                  </Button>
                </div>
              ) : null}

              <div className="space-y-2">
                <p className="text-xs font-medium text-muted">علت مراجعه</p>
                <div className="flex flex-wrap gap-2">
                  {SYMPTOMS.map((s) => (
                    <FilterChip
                      key={s.id}
                      active={symptomId === s.id}
                      onClick={() => setSymptomId((cur) => (cur === s.id ? null : s.id))}
                    >
                      {s.name}
                    </FilterChip>
                  ))}
                </div>
                {symptom ? (
                  <div className="flex flex-wrap items-center gap-2 rounded-lg bg-surface-2 px-3 py-2 text-sm">
                    <p className="min-w-0 flex-1 text-muted">{symptom.hint}</p>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => addServices(symptom.serviceIds)}
                    >
                      افزودن پیشنهادی
                    </Button>
                  </div>
                ) : null}
              </div>

              <div className="relative">
                <Search className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-faint" />
                <Input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="جستجوی خدمت؛ جعبه فرمان، سیبک، طبق، کمک…"
                  className="pr-10"
                />
              </div>

              <div className="max-w-full overflow-x-auto pb-1">
                <div className="flex w-max gap-2">
                  <FilterChip active={category === "all"} onClick={() => setCategory("all")}>
                    همه
                  </FilterChip>
                  {CATEGORIES.map((c) => (
                    <FilterChip
                      key={c.id}
                      active={category === c.id}
                      onClick={() => setCategory(c.id)}
                    >
                      {c.name}
                    </FilterChip>
                  ))}
                </div>
              </div>

              {grouped.length === 0 ? (
                <div className="rounded-xl border border-line bg-surface px-5 py-10 text-center text-sm text-muted">
                  خدمتی با این جستجو برای {carName} پیدا نشد.
                </div>
              ) : (
                grouped.map((group) => (
                  <div
                    key={group.id}
                    className="overflow-hidden rounded-xl border border-line bg-surface"
                  >
                    <h2 className="border-b border-line bg-surface-2/60 px-4 py-2.5 text-sm font-semibold">
                      {group.name}
                    </h2>
                    <ul>
                      {group.items.map(({ service, rate }) => {
                        const inCart = lines.find((l) => l.serviceId === service.id);
                        const marked = highlight.has(service.id);
                        return (
                          <li
                            key={service.id}
                            className={cn(
                              "flex items-center gap-3 border-b border-line/70 px-4 py-3 last:border-b-0",
                              marked && "bg-accent/5",
                            )}
                          >
                            <div className="min-w-0 flex-1">
                              <p className="text-sm font-medium">{service.name}</p>
                              <p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted">
                                <span>{service.unitLabel}</span>
                                {rate.source !== "union-1404" ? (
                                  <Badge
                                    variant={rate.source === "estimated" ? "warn" : "default"}
                                  >
                                    {SOURCE_LABEL[rate.source]}
                                  </Badge>
                                ) : null}
                                {inCart ? (
                                  <Badge variant="outline">
                                    در فاکتور × {formatNumber(inCart.qty, persian)}
                                  </Badge>
                                ) : null}
                              </p>
                            </div>
                            <p className="shrink-0 text-sm font-semibold tabular-nums">
                              {money(rate.toman)}
                            </p>
                            <Button
                              size="icon"
                              variant={inCart ? "default" : "outline"}
                              aria-label={`افزودن ${service.name}`}
                              onClick={() => addService(service.id)}
                            >
                              {inCart ? <Check /> : <Plus />}
                            </Button>
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                ))
              )}

              <p className="text-xs leading-6 text-faint">{RATE_YEAR_NOTE}</p>
            </section>

            <aside className="no-print hidden min-w-0 lg:sticky lg:top-28 lg:block lg:self-start">
              <InvoiceCard {...invoiceProps} />
            </aside>
          </div>
        ) : null}

        {tab === "table" ? <RateTable unit={unit} persian={persian} carId={carId} /> : null}

        {tab === "saved" ? (
          <SavedList
            saved={saved}
            persian={persian}
            unit={unit}
            onLoad={(id) => {
              loadSaved(id);
              const inv = saved.find((x) => x.id === id);
              const next = inv ? getCar(inv.carId) : undefined;
              if (next) setBrandFilter(next.brand);
              setTab("estimate");
              setInvoiceOpen(true);
            }}
            onDelete={deleteSaved}
          />
        ) : null}
      </main>

      <PrintInvoice
        shopName={shopName}
        shopPhone={shopPhone}
        shopAddress={shopAddress}
        customerName={customerName}
        plate={plate}
        note={note}
        carName={carName}
        lines={lines}
        partsToman={partsToman}
        discountPercent={discountPercent}
        vatEnabled={vatEnabled}
        unit={unit}
        persian={persian}
      />

      {tab === "estimate" ? (
        <div className="no-print fixed inset-x-3 bottom-4 z-20 rounded-xl border border-line bg-surface p-3 shadow-lg lg:hidden">
          <div className="flex items-center gap-3">
            <div className="min-w-0 flex-1">
              <p className="text-xs text-muted">{carName}</p>
              <p className="font-semibold tabular-nums">{money(total)}</p>
            </div>
            <Button onClick={() => setInvoiceOpen(true)}>مشاهده فاکتور</Button>
          </div>
        </div>
      ) : null}

      {invoiceOpen ? (
        <div className="no-print fixed inset-0 z-40 lg:hidden">
          <button
            type="button"
            aria-label="بستن فاکتور"
            className="absolute inset-0 bg-ink/40"
            onClick={() => setInvoiceOpen(false)}
          />
          <div className="absolute inset-x-0 bottom-0 max-h-[92svh] overflow-auto rounded-t-2xl bg-bg p-3 pb-6">
            <div className="mx-auto mb-3 h-1 w-10 rounded-full bg-line" />
            <InvoiceCard {...invoiceProps} />
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Toggle({
  on,
  onClick,
  label,
}: {
  on: boolean;
  onClick: () => void;
  label: string;
}) {
  return (
    <Button variant={on ? "default" : "outline"} size="sm" onClick={onClick}>
      {label}
    </Button>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-11 shrink-0 rounded-full px-3 text-sm font-medium transition-opacity duration-150",
        active ? "bg-accent text-accent-fg" : "bg-surface text-muted ring-1 ring-line",
      )}
    >
      {children}
    </button>
  );
}

function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className={cn("flex items-center justify-between", strong && "text-base font-semibold")}>
      <span className={strong ? "" : "text-muted"}>{label}</span>
      <span className="tabular-nums">{value}</span>
    </div>
  );
}

interface InvoiceCardProps {
  customerName: string;
  plate: string;
  note: string;
  carName: string;
  lines: ReturnType<typeof useEstimator.getState>["lines"];
  partsToman: number;
  discountPercent: number;
  vatEnabled: boolean;
  unit: "toman" | "rial";
  persian: boolean;
  money: (n: number) => string;
  labor: number;
  total: number;
  vat: number;
  disc: number;
  customName: string;
  customPrice: string;
  hasPackage: boolean;
  hasOther: boolean;
  onQty: (id: string, qty: number) => void;
  onRemove: (id: string) => void;
  onCustomName: (v: string) => void;
  onCustomPrice: (v: string) => void;
  onCustomSubmit: (e: FormEvent) => void;
  onParts: (n: number) => void;
  onDiscount: (n: number) => void;
  onCustomer: (p: { customerName?: string; plate?: string; note?: string }) => void;
  onPrint: () => void;
  onSave: () => void;
  onCopy: () => void;
  onClear: () => void;
}

function InvoiceCard(p: InvoiceCardProps) {
  return (
    <div className="flex max-h-none flex-col overflow-hidden rounded-xl border border-line bg-surface lg:max-h-[calc(100svh-8.5rem)]">
      <div className="shrink-0 px-4 py-3">
        <p className="text-xs text-muted">فاکتور اجرت · {p.carName}</p>
        <p className="text-lg font-semibold tabular-nums">{p.money(p.total)}</p>
      </div>

      <div className="grid grid-cols-2 gap-2 border-t border-line p-3">
        <div className="space-y-1">
          <Label htmlFor="cust">نام مشتری</Label>
          <Input
            id="cust"
            value={p.customerName}
            onChange={(e) => p.onCustomer({ customerName: e.target.value })}
          />
        </div>
        <div className="space-y-1">
          <Label>پلاک</Label>
          <IranPlateInput
            value={p.plate}
            onChange={(plate) => p.onCustomer({ plate })}
          />
        </div>
      </div>

      {p.hasPackage && p.hasOther ? (
        <p className="mx-3 mb-2 rounded-md bg-stamp/10 px-3 py-2 text-xs leading-5 text-stamp">
          پکیج کامل و ردیف‌های جزئی هم‌زمان در فاکتور هستند؛ ممکن است اجرت دو بار محاسبه شود.
        </p>
      ) : null}

      {p.lines.length === 0 ? (
        <p className="px-4 py-8 text-center text-sm text-muted">خدمت را از فهرست اضافه کنید.</p>
      ) : (
        <ul className="min-h-0 flex-1 overflow-auto border-y border-line">
          {p.lines.map((line) => (
            <li key={line.id} className="flex items-start gap-2 px-3 py-2.5">
              <div className="min-w-0 flex-1">
                <p className="text-sm leading-snug">{line.name}</p>
                <p className="mt-0.5 text-xs tabular-nums text-muted">
                  {p.money(line.unitToman)}
                  {line.source === "estimated" ? " · برآورد" : ""}
                </p>
              </div>
              <div className="flex shrink-0 items-center">
                <Button
                  size="icon"
                  variant="ghost"
                  aria-label="کم کردن"
                  onClick={() => (line.qty <= 1 ? p.onRemove(line.id) : p.onQty(line.id, line.qty - 1))}
                >
                  <Minus />
                </Button>
                <span className="w-6 text-center text-sm tabular-nums">
                  {formatNumber(line.qty, p.persian)}
                </span>
                <Button
                  size="icon"
                  variant="ghost"
                  aria-label="افزودن"
                  onClick={() => p.onQty(line.id, line.qty + 1)}
                >
                  <Plus />
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  aria-label="حذف"
                  onClick={() => p.onRemove(line.id)}
                >
                  <Trash2 />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <form onSubmit={p.onCustomSubmit} className="grid shrink-0 grid-cols-6 gap-2 p-3">
        <Input
          className="col-span-3"
          placeholder="ردیف دستی"
          value={p.customName}
          onChange={(e) => p.onCustomName(e.target.value)}
        />
        <Input
          className="col-span-2 text-right"
          placeholder={p.unit === "rial" ? "ریال" : "تومان"}
          inputMode="numeric"
          dir="ltr"
          value={p.customPrice}
          onChange={(e) => p.onCustomPrice(e.target.value)}
        />
        <Button type="submit" variant="outline" size="icon" aria-label="افزودن ردیف">
          <Plus />
        </Button>
      </form>

      <div className="shrink-0 space-y-2 px-3 pb-3">
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <Label htmlFor="parts">مبلغ قطعات</Label>
            <Input
              id="parts"
              inputMode="numeric"
              dir="ltr"
              className="text-right tabular-nums"
              value={p.partsToman ? String(p.unit === "rial" ? p.partsToman * 10 : p.partsToman) : ""}
              onChange={(e) => {
                const n = Number(e.target.value.replace(/[^\d]/g, "")) || 0;
                p.onParts(p.unit === "rial" ? n / 10 : n);
              }}
            />
          </div>
          <div className="space-y-1">
            <Label htmlFor="disc">تخفیف ٪</Label>
            <Input
              id="disc"
              inputMode="numeric"
              dir="ltr"
              className="text-right tabular-nums"
              value={p.discountPercent || ""}
              onChange={(e) => p.onDiscount(Number(e.target.value.replace(/[^\d]/g, "")) || 0)}
            />
          </div>
        </div>
        <div className="space-y-1">
          <Label htmlFor="note">توضیحات</Label>
          <Input
            id="note"
            value={p.note}
            onChange={(e) => p.onCustomer({ note: e.target.value })}
          />
        </div>
      </div>

      <div className="shrink-0 space-y-1 border-t border-line bg-surface-2/50 px-4 py-3 text-sm">
        <Row label="جمع اجرت" value={p.money(p.labor)} />
        {p.partsToman > 0 ? <Row label="قطعات" value={p.money(p.partsToman)} /> : null}
        {p.discountPercent > 0 ? (
          <Row
            label={`تخفیف ${formatNumber(p.discountPercent, p.persian)}٪`}
            value={p.money(p.disc)}
          />
        ) : null}
        {p.vatEnabled ? <Row label="مالیات ارزش افزوده ۹٪" value={p.money(p.vat)} /> : null}
        <Row label="قابل پرداخت" value={p.money(p.total)} strong />
        <p className="pt-1 text-xs leading-5 text-muted">{tomanToWords(p.total)}</p>
      </div>

      <div className="grid shrink-0 grid-cols-2 gap-2 p-3">
        <Button onClick={p.onPrint} disabled={p.lines.length === 0}>
          <Printer />
          چاپ فاکتور
        </Button>
        <Button variant="outline" onClick={p.onSave} disabled={p.lines.length === 0}>
          <Save />
          ذخیره
        </Button>
        <Button variant="outline" onClick={p.onCopy} disabled={p.lines.length === 0}>
          <Copy />
          کپی متن
        </Button>
        <Button
          variant="ghost"
          className="text-stamp"
          onClick={p.onClear}
          disabled={p.lines.length === 0}
        >
          پاک کردن
        </Button>
      </div>
    </div>
  );
}

function RateTable({
  unit,
  persian,
  carId,
}: {
  unit: "toman" | "rial";
  persian: boolean;
  carId: string;
}) {
  const [q, setQ] = useState("");
  const [onlyCar, setOnlyCar] = useState(true);
  const money = (n: number) => formatMoney(n, unit, persian);
  const rows = SERVICES.filter((service) => !q || service.name.includes(q));
  const cols = onlyCar ? CARS.filter((c) => c.id === carId) : CARS;

  return (
    <div className="no-print min-w-0 space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative min-w-0 flex-1">
          <Search className="pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-faint" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="جستجو در جدول نرخ‌ها"
            className="pr-10"
          />
        </div>
        <Toggle
          on={onlyCar}
          onClick={() => setOnlyCar((v) => !v)}
          label={onlyCar ? "فقط این خودرو" : "همه خودروها"}
        />
      </div>
      <div className="overflow-auto rounded-xl border border-line bg-surface">
        <table className="w-max min-w-full border-collapse text-sm">
          <thead className="sticky top-0 bg-surface-2">
            <tr>
              <th className="sticky right-0 bg-surface-2 px-3 py-2 text-right font-medium">خدمت</th>
              {cols.map((car) => (
                <th key={car.id} className="px-3 py-2 text-left font-medium whitespace-nowrap">
                  {car.name}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((service) => (
              <tr key={service.id} className="border-t border-line/70">
                <th className="sticky right-0 bg-surface px-3 py-2 text-right font-medium">
                  <span className="block">{service.name}</span>
                  <span className="text-xs font-normal text-muted">{service.unitLabel}</span>
                </th>
                {cols.map((car) => {
                  const cell = getRate(car.id, service.id);
                  return (
                    <td key={car.id} className="px-3 py-2 text-left tabular-nums">
                      {cell ? (
                        <span
                          className={cn(
                            cell.source === "estimated" && "text-muted",
                            cell.source === "union-1405" && "text-accent",
                          )}
                        >
                          {money(cell.toman)}
                        </span>
                      ) : (
                        <span className="text-faint">—</span>
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="text-xs leading-6 text-faint">{RATE_YEAR_NOTE}</p>
    </div>
  );
}

function SavedList({
  saved,
  persian,
  unit,
  onLoad,
  onDelete,
}: {
  saved: ReturnType<typeof useEstimator.getState>["saved"];
  persian: boolean;
  unit: "toman" | "rial";
  onLoad: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  if (saved.length === 0) {
    return (
      <div className="no-print rounded-xl border border-line bg-surface px-5 py-16 text-center">
        <p className="font-medium">فاکتور ذخیره‌شده‌ای نیست</p>
        <p className="mt-1 text-sm text-muted">پس از محاسبه اجرت، فاکتور را ذخیره کنید.</p>
      </div>
    );
  }

  return (
    <ul className="no-print space-y-2">
      {saved.map((inv) => (
        <li
          key={inv.id}
          className="flex flex-wrap items-center gap-3 rounded-xl border border-line bg-surface px-4 py-3"
        >
          <div className="min-w-0 flex-1">
            <p className="font-medium">
              {inv.carName}
              {inv.customerName ? ` · ${inv.customerName}` : ""}
              {inv.plate ? ` · ${inv.plate}` : ""}
            </p>
            <p className="text-xs text-muted">
              {formatJalali(new Date(inv.createdAt), persian)} ·{" "}
              {formatNumber(inv.lines.length, persian)} ردیف
            </p>
          </div>
          <p className="text-sm font-semibold tabular-nums">
            {formatMoney(inv.totalToman, unit, persian)}
          </p>
          <Button size="sm" variant="outline" onClick={() => onLoad(inv.id)}>
            باز کردن
          </Button>
          <Button
            size="icon"
            variant="ghost"
            aria-label="حذف فاکتور"
            onClick={() => onDelete(inv.id)}
          >
            <X />
          </Button>
        </li>
      ))}
    </ul>
  );
}
