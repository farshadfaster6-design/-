//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BU96by60.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BwYi8Wmr.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BwYi8Wmr.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DYRqENUf.js"]
	}
} });
//#endregion
export { tsrStartManifest };
