import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Search, c as Plus, d as Check, i as Settings2, l as Minus, o as Save, r as Trash2, s as Printer, t as X, u as Copy } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-NPa4Q3jD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var LETTERS = [
	"ب",
	"ج",
	"د",
	"س",
	"ص",
	"ط",
	"ع",
	"ق",
	"ل",
	"م",
	"ن",
	"و",
	"ه",
	"ی",
	"ت"
];
function joinPlate(parts) {
	const body = `${parts.left}${parts.letter}${parts.mid}`;
	if (!body && !parts.province) return "";
	return parts.province ? `${body}-${parts.province}` : body;
}
function IranPlateInput({ value, onChange }) {
	const [left, rest] = value.split("-");
	const body = left ?? "";
	const province = rest ?? "";
	const letterIdx = [...body].findIndex((ch) => Number.isNaN(Number(ch)));
	const numLeft = letterIdx === -1 ? body.slice(0, 2) : body.slice(0, letterIdx);
	const letter = letterIdx === -1 ? "" : body.slice(letterIdx, letterIdx + 1);
	const mid = letterIdx === -1 ? "" : body.slice(letterIdx + 1).replace(/\D/g, "").slice(0, 3);
	function emit(next) {
		onChange(joinPlate({
			left: (next.left ?? numLeft).replace(/\D/g, "").slice(0, 2),
			letter: next.letter ?? letter,
			mid: (next.mid ?? mid).replace(/\D/g, "").slice(0, 3),
			province: (next.province ?? province).replace(/\D/g, "").slice(0, 2)
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		dir: "ltr",
		className: "flex h-11 overflow-hidden rounded-md border border-ink/20 bg-surface text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: numLeft,
				onChange: (v) => emit({ left: v }),
				maxLength: 2,
				ariaLabel: "دو رقم سمت چپ پلاک",
				className: "w-12"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				"aria-label": "حرف پلاک",
				value: letter,
				onChange: (e) => emit({ letter: e.target.value }),
				className: "w-14 border-x border-ink/15 bg-surface text-center text-sm font-semibold outline-none",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "—"
				}), LETTERS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: l,
					children: l
				}, l))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: mid,
				onChange: (v) => emit({ mid: v }),
				maxLength: 3,
				ariaLabel: "سه رقم پلاک",
				className: "w-16"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-12 shrink-0 flex-col items-center justify-center bg-plate-blue text-xs leading-none text-accent-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-semibold",
					children: "ایران"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-0.5 tracking-wide",
					children: "I.R."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				value: province,
				onChange: (v) => emit({ province: v }),
				maxLength: 2,
				ariaLabel: "کد استان",
				className: "w-12"
			})
		]
	});
}
function Field({ value, onChange, maxLength, ariaLabel, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		inputMode: "numeric",
		maxLength,
		"aria-label": ariaLabel,
		value,
		onChange: (e) => onChange(e.target.value.replace(/\D/g, "").slice(0, maxLength)),
		className: cn("h-full bg-transparent text-center text-sm font-semibold tabular-nums outline-none", className)
	});
}
function IranPlatePreview({ value }) {
	if (!value) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-muted",
		children: "—"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-medium tracking-wide",
		dir: "ltr",
		children: value
	});
}
function laborTotal(lines) {
	return lines.reduce((sum, line) => sum + line.unitToman * line.qty, 0);
}
function afterDiscount(laborToman, partsToman, discountPercent) {
	const sub = laborToman + Math.max(0, partsToman);
	const cut = Math.min(100, Math.max(0, discountPercent)) / 100;
	return Math.round(sub * (1 - cut));
}
function grandTotal(lines, partsToman, discountPercent, vatEnabled) {
	const after = afterDiscount(laborTotal(lines), partsToman, discountPercent);
	return vatEnabled ? Math.round(after * 1.09) : after;
}
function vatAmount(lines, partsToman, discountPercent, vatEnabled) {
	const after = afterDiscount(laborTotal(lines), partsToman, discountPercent);
	return vatEnabled ? grandTotal(lines, partsToman, discountPercent, true) - after : 0;
}
function discountAmount(laborToman, partsToman, discountPercent) {
	return laborToman + Math.max(0, partsToman) - afterDiscount(laborToman, partsToman, discountPercent);
}
var ONES = [
	"",
	"یک",
	"دو",
	"سه",
	"چهار",
	"پنج",
	"شش",
	"هفت",
	"هشت",
	"نه"
];
var TEENS = [
	"ده",
	"یازده",
	"دوازده",
	"سیزده",
	"چهارده",
	"پانزده",
	"شانزده",
	"هفده",
	"هجده",
	"نوزده"
];
var TENS = [
	"",
	"",
	"بیست",
	"سی",
	"چهل",
	"پنجاه",
	"شصت",
	"هفتاد",
	"هشتاد",
	"نود"
];
var HUNDREDS = [
	"",
	"یکصد",
	"دویست",
	"سیصد",
	"چهارصد",
	"پانصد",
	"ششصد",
	"هفتصد",
	"هشتصد",
	"نهصد"
];
var SCALES = [
	"",
	"هزار",
	"میلیون",
	"میلیارد",
	"هزار میلیارد"
];
function chunkToWords(n) {
	const h = Math.floor(n / 100);
	const rest = n % 100;
	const parts = [];
	if (h) parts.push(HUNDREDS[h] ?? "");
	if (rest >= 10 && rest < 20) parts.push(TEENS[rest - 10] ?? "");
	else {
		const t = Math.floor(rest / 10);
		const o = rest % 10;
		if (t) parts.push(TENS[t] ?? "");
		if (o) parts.push(ONES[o] ?? "");
	}
	return parts.filter(Boolean).join(" و ");
}
function tomanToWords(toman) {
	if (toman === 0) return "صفر تومان";
	if (toman < 0) return "نامعتبر";
	const whole = Math.round(toman);
	const parts = [];
	let remaining = whole;
	let scale = 0;
	while (remaining > 0 && scale < SCALES.length) {
		const chunk = remaining % 1e3;
		if (chunk) {
			const words = chunkToWords(chunk);
			const scaleName = SCALES[scale];
			parts.unshift(scaleName ? `${words} ${scaleName}` : words);
		}
		remaining = Math.floor(remaining / 1e3);
		scale += 1;
	}
	return `${parts.join(" و ")} تومان`;
}
function formatToman(toman, persian = true) {
	const formatted = new Intl.NumberFormat(persian ? "fa-IR" : "en-US").format(Math.round(toman));
	return persian ? `${formatted} تومان` : `${formatted} Toman`;
}
function formatRial(toman, persian = true) {
	const formatted = new Intl.NumberFormat(persian ? "fa-IR" : "en-US").format(Math.round(toman * 10));
	return persian ? `${formatted} ریال` : `${formatted} Rial`;
}
function formatMoney(toman, unit, persian = true) {
	return unit === "rial" ? formatRial(toman, persian) : formatToman(toman, persian);
}
function formatNumber(n, persian = true) {
	return new Intl.NumberFormat(persian ? "fa-IR" : "en-US").format(n);
}
var JALALI_MONTHS = [
	"فروردین",
	"اردیبهشت",
	"خرداد",
	"تیر",
	"مرداد",
	"شهریور",
	"مهر",
	"آبان",
	"آذر",
	"دی",
	"بهمن",
	"اسفند"
];
function gregorianToJalali(gy, gm, gd) {
	const g_d_m = [
		0,
		31,
		59,
		90,
		120,
		151,
		181,
		212,
		243,
		273,
		304,
		334
	];
	let jy = gy <= 1600 ? 0 : 979;
	gy -= gy <= 1600 ? 621 : 1600;
	const gy2 = gm > 2 ? gy + 1 : gy;
	let days = 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) - 80 + gd + (g_d_m[gm - 1] ?? 0);
	jy += 33 * Math.floor(days / 12053);
	days %= 12053;
	jy += 4 * Math.floor(days / 1461);
	days %= 1461;
	if (days > 365) {
		jy += Math.floor((days - 1) / 365);
		days = (days - 1) % 365;
	}
	const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
	const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
	return [
		jy,
		jm,
		jd
	];
}
function formatJalali(date = /* @__PURE__ */ new Date(), persian = true) {
	const [jy, jm, jd] = gregorianToJalali(date.getFullYear(), date.getMonth() + 1, date.getDate());
	const month = JALALI_MONTHS[jm - 1] ?? "";
	const fa = "۰۱۲۳۴۵۶۷۸۹";
	const toDigits = (n) => persian ? String(n).replace(/\d/g, (d) => fa[Number(d)] ?? d) : String(n);
	return `${toDigits(jd)} ${month} ${toDigits(jy)}`;
}
var CATEGORIES = [
	{
		id: "package",
		name: "پکیج کامل"
	},
	{
		id: "mount",
		name: "دسته‌موتور"
	},
	{
		id: "arm",
		name: "طبق و بوش"
	},
	{
		id: "steering",
		name: "فرمان و جعبه فرمان"
	},
	{
		id: "shock",
		name: "کمک‌فنر و سگدست"
	},
	{
		id: "sway",
		name: "موج‌گیر"
	},
	{
		id: "subframe",
		name: "رام"
	},
	{
		id: "align",
		name: "میزان فرمان"
	}
];
var BRANDS = [
	{
		id: "saipa",
		name: "سایپا"
	},
	{
		id: "ikco",
		name: "ایران‌خودرو"
	},
	{
		id: "renault",
		name: "رنو"
	},
	{
		id: "hyundai",
		name: "هیوندای"
	},
	{
		id: "kia",
		name: "کیا"
	},
	{
		id: "toyota",
		name: "تویوتا"
	},
	{
		id: "lexus",
		name: "لکسوس"
	},
	{
		id: "china",
		name: "چینی"
	}
];
var CARS = [
	{
		id: "pride",
		name: "پراید",
		brand: "saipa",
		family: "pride"
	},
	{
		id: "tiba",
		name: "تیبا",
		brand: "saipa",
		family: "tiba"
	},
	{
		id: "saina",
		name: "ساینا",
		brand: "saipa",
		family: "tiba"
	},
	{
		id: "quick",
		name: "کوییک",
		brand: "saipa",
		family: "tiba"
	},
	{
		id: "rio",
		name: "ریو",
		brand: "saipa",
		family: "tiba"
	},
	{
		id: "mazda",
		name: "وانت مزدا",
		brand: "saipa",
		family: "ikco206"
	},
	{
		id: "405",
		name: "پژو ۴۰۵",
		brand: "ikco",
		family: "ikco405"
	},
	{
		id: "pars",
		name: "پژو پارس",
		brand: "ikco",
		family: "ikco405"
	},
	{
		id: "samand",
		name: "سمند",
		brand: "ikco",
		family: "ikco405"
	},
	{
		id: "samand-ef7",
		name: "سمند EF7",
		brand: "ikco",
		family: "ikco405"
	},
	{
		id: "206",
		name: "پژو ۲۰۶",
		brand: "ikco",
		family: "ikco206"
	},
	{
		id: "207",
		name: "پژو ۲۰۷",
		brand: "ikco",
		family: "ikco206"
	},
	{
		id: "rana",
		name: "رانا",
		brand: "ikco",
		family: "ikco206"
	},
	{
		id: "dena",
		name: "دنا",
		brand: "ikco",
		family: "dena"
	},
	{
		id: "dena-plus",
		name: "دنا پلاس",
		brand: "ikco",
		family: "dena"
	},
	{
		id: "l90",
		name: "تندر ۹۰",
		brand: "renault",
		family: "l90"
	},
	{
		id: "sandro",
		name: "ساندرو",
		brand: "renault",
		family: "l90"
	},
	{
		id: "megane",
		name: "مگان",
		brand: "renault",
		family: "megane"
	},
	{
		id: "verna",
		name: "ورنا",
		brand: "hyundai",
		family: "verna"
	},
	{
		id: "accent",
		name: "اکسنت",
		brand: "hyundai",
		family: "verna"
	},
	{
		id: "i20",
		name: "i20",
		brand: "hyundai",
		family: "verna"
	},
	{
		id: "elantra",
		name: "النترا",
		brand: "hyundai",
		family: "verna"
	},
	{
		id: "avante",
		name: "آوانته",
		brand: "hyundai",
		family: "verna"
	},
	{
		id: "sonata",
		name: "سوناتا",
		brand: "hyundai",
		family: "hyundaiMid"
	},
	{
		id: "tucson",
		name: "توسان",
		brand: "hyundai",
		family: "hyundaiMid"
	},
	{
		id: "ix35",
		name: "ix35",
		brand: "hyundai",
		family: "hyundaiMid"
	},
	{
		id: "santafe",
		name: "سانتافه",
		brand: "hyundai",
		family: "hyundaiSuv"
	},
	{
		id: "cerato",
		name: "سراتو",
		brand: "kia",
		family: "kiaCerato"
	},
	{
		id: "optima",
		name: "اپتیما",
		brand: "kia",
		family: "kiaCerato"
	},
	{
		id: "sportage",
		name: "اسپورتیج",
		brand: "kia",
		family: "kiaSuv"
	},
	{
		id: "sorento",
		name: "سورنتو",
		brand: "kia",
		family: "kiaSuv"
	},
	{
		id: "yaris",
		name: "یاریس",
		brand: "toyota",
		family: "toyotaCompact"
	},
	{
		id: "corolla",
		name: "کرولا",
		brand: "toyota",
		family: "toyotaCompact"
	},
	{
		id: "camry",
		name: "کمری",
		brand: "toyota",
		family: "toyotaCamry"
	},
	{
		id: "rav4",
		name: "RAV4",
		brand: "toyota",
		family: "toyotaSuv"
	},
	{
		id: "hilux",
		name: "هایلوکس",
		brand: "toyota",
		family: "toyotaPrado"
	},
	{
		id: "prado",
		name: "پرادو",
		brand: "toyota",
		family: "toyotaPrado"
	},
	{
		id: "landcruiser",
		name: "لندکروز",
		brand: "toyota",
		family: "toyotaPrado"
	},
	{
		id: "lexus-is",
		name: "لکسوس IS",
		brand: "lexus",
		family: "lexusSedan"
	},
	{
		id: "lexus-es",
		name: "لکسوس ES",
		brand: "lexus",
		family: "lexusSedan"
	},
	{
		id: "lexus-nx",
		name: "لکسوس NX",
		brand: "lexus",
		family: "lexusSuv"
	},
	{
		id: "lexus-rx",
		name: "لکسوس RX",
		brand: "lexus",
		family: "lexusSuv"
	},
	{
		id: "jac-s5",
		name: "جک S5",
		brand: "china",
		family: "china"
	},
	{
		id: "jac-j5",
		name: "جک J5",
		brand: "china",
		family: "china"
	},
	{
		id: "arrizo5",
		name: "آریزو ۵",
		brand: "china",
		family: "china"
	},
	{
		id: "tiggo5",
		name: "تیگو ۵",
		brand: "china",
		family: "china"
	},
	{
		id: "x33",
		name: "ام‌وی‌ام X33",
		brand: "china",
		family: "china"
	}
];
var SERVICES = [
	{
		id: "full_front",
		name: "تعمیر کامل جلوبندی",
		category: "package",
		qtyKind: "fixed",
		unitLabel: "دستمزد کامل",
		maxQty: 1,
		hint: "نرخ مصوب ۱۴۰۵ اتحادیه تهران؛ بدون احتساب قطعات و کمک‌فنر جداگانه"
	},
	{
		id: "full_no_shock",
		name: "تعمیر کامل جلوبندی بدون کمک",
		category: "package",
		qtyKind: "fixed",
		unitLabel: "دستمزد کامل",
		maxQty: 1,
		hint: "پکیج بدون تعویض کمک‌فنر"
	},
	{
		id: "mount_upper",
		name: "تعویض دسته‌موتور بالا راست",
		category: "mount",
		qtyKind: "fixed",
		unitLabel: "عدد",
		maxQty: 1
	},
	{
		id: "mount_front",
		name: "تعویض پایه دسته‌موتور جلو یا چپ",
		category: "mount",
		qtyKind: "fixed",
		unitLabel: "عدد",
		maxQty: 1
	},
	{
		id: "mount_round",
		name: "تعویض دسته‌موتور جلو گرد",
		category: "mount",
		qtyKind: "fixed",
		unitLabel: "عدد",
		maxQty: 1
	},
	{
		id: "control_arm",
		name: "باز و بست طبق",
		category: "arm",
		qtyKind: "both",
		unitLabel: "هر دو طرف",
		maxQty: 1,
		hint: "نرخ برای هر دو طرف است"
	},
	{
		id: "arm_bush",
		name: "تعویض بوش طبق",
		category: "arm",
		qtyKind: "perUnit",
		unitLabel: "هر عدد",
		maxQty: 4
	},
	{
		id: "lower_ball",
		name: "تعویض سیبک زیر کمک",
		category: "arm",
		qtyKind: "perSide",
		unitLabel: "هر طرف",
		maxQty: 2
	},
	{
		id: "tie_rod",
		name: "تعویض سیبک فرمان",
		category: "steering",
		qtyKind: "perSide",
		unitLabel: "هر طرف",
		maxQty: 2
	},
	{
		id: "inner_tie",
		name: "تعویض قرقری فرمان",
		category: "steering",
		qtyKind: "perSide",
		unitLabel: "هر طرف",
		maxQty: 2
	},
	{
		id: "bellows",
		name: "تعویض گردگیر فرمان",
		category: "steering",
		qtyKind: "perSide",
		unitLabel: "هر طرف",
		maxQty: 2
	},
	{
		id: "steering_box",
		name: "باز و بست و تعمیر کامل جعبه فرمان",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1,
		hint: "پیاده و سوار کردن جعبه فرمان و تعمیر کامل داخل جعبه؛ بدون قطعه"
	},
	{
		id: "hyd_pump",
		name: "تعویض پمپ هیدرولیک فرمان",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "hyd_pump_repair",
		name: "تعمیر پمپ هیدرولیک فرمان",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "hyd_reservoir",
		name: "تعویض منبع هیدرولیک فرمان",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "hyd_hose_high",
		name: "تعویض شلنگ فشار قوی هیدرولیک",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "hyd_hose_low",
		name: "تعویض شلنگ فشار ضعیف هیدرولیک",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "hyd_hose_to_box",
		name: "تعویض شلنگ منبع به جعبه فرمان",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "eps_motor",
		name: "تعویض موتور برقی فرمان",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1,
		hint: "برای خودروهای فرمان برقی (EPS)"
	},
	{
		id: "steering_cross",
		name: "تعویض چهارشاخه فرمان",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "steering_tele",
		name: "باز و بست تلسکوپی فرمان",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "hyd_hoses",
		name: "تعویض لوله‌های هیدرولیک",
		category: "steering",
		qtyKind: "fixed",
		unitLabel: "جفت",
		maxQty: 1
	},
	{
		id: "front_shock",
		name: "تعویض کمک‌فنر جلو",
		category: "shock",
		qtyKind: "perUnit",
		unitLabel: "هر عدد",
		maxQty: 2
	},
	{
		id: "rear_shock",
		name: "تعویض کمک‌فنر عقب",
		category: "shock",
		qtyKind: "perUnit",
		unitLabel: "هر عدد",
		maxQty: 2
	},
	{
		id: "knuckle_bearing",
		name: "تعویض بلبرینگ چرخ جلو و باز و بست سگدست",
		category: "shock",
		qtyKind: "perSide",
		unitLabel: "هر طرف",
		maxQty: 2
	},
	{
		id: "sway_bush",
		name: "تعویض لاستیک‌های چاک‌دار موج‌گیر",
		category: "sway",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "sway_bar",
		name: "تعویض میل موج‌گیر جلو",
		category: "sway",
		qtyKind: "perSide",
		unitLabel: "هر طرف",
		maxQty: 2
	},
	{
		id: "subframe",
		name: "تعویض رام زیر موتور",
		category: "subframe",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "align_manual",
		name: "میزان فرمان دستی",
		category: "align",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "align_machine",
		name: "میزان فرمان با دستگاه",
		category: "align",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "wrenching",
		name: "آچارکشی جلوبندی",
		category: "align",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	},
	{
		id: "wheel_adj",
		name: "تنظیم غربیلک فرمان",
		category: "align",
		qtyKind: "fixed",
		unitLabel: "دستمزد",
		maxQty: 1
	}
];
var U = "union-1404";
var E = "estimated";
var U5 = "union-1405";
function r(toman, source) {
	return {
		toman,
		source
	};
}
function scale(base, factor) {
	const out = {};
	for (const [id, cell] of Object.entries(base)) out[id] = r(Math.round(cell.toman * factor / 1e4) * 1e4, E);
	return out;
}
/** اجرت جعبه فرمان و هیدرولیک — تومان */
function box(values, source) {
	const out = {
		steering_box: r(values.steering_box, source),
		hyd_pump: r(values.hyd_pump, source),
		hyd_pump_repair: r(values.hyd_pump_repair, source),
		hyd_reservoir: r(values.hyd_reservoir, source),
		hyd_hose_high: r(values.hyd_hose_high, source),
		hyd_hose_low: r(values.hyd_hose_low, source),
		hyd_hose_to_box: r(values.hyd_hose_to_box, source)
	};
	if (values.eps_motor) out.eps_motor = r(values.eps_motor, E);
	return out;
}
/**
* Individual rates in TOMAN.
* union-1404: اتحادیه تهران، جدول جلوبندی ۸ دی ۱۴۰۴ (منبع به ریال؛ اینجا تومان).
* estimated: ردیف‌های ناموجود در جدول دی ۱۴۰۴، با ضریب حدود ۱٫۹۷ از نرخ ۱۴۰۳.
* union-1405: پکیج تعمیر کامل جلوبندی و اجرت جعبه فرمان از نرخ‌نامه ۱۴۰۵.
*/
var PRIDE_BOX = box({
	steering_box: 15e5,
	hyd_pump: 6e5,
	hyd_pump_repair: 8e5,
	hyd_reservoir: 4e5,
	hyd_hose_high: 6e5,
	hyd_hose_low: 4e5,
	hyd_hose_to_box: 65e4
}, U5);
var TIBA_BOX = box({
	steering_box: 17e5,
	hyd_pump: 65e4,
	hyd_pump_repair: 9e5,
	hyd_reservoir: 45e4,
	hyd_hose_high: 65e4,
	hyd_hose_low: 4e5,
	hyd_hose_to_box: 7e5
}, U5);
var IKCO405_BOX = box({
	steering_box: 22e5,
	hyd_pump: 75e4,
	hyd_pump_repair: 12e5,
	hyd_reservoir: 55e4,
	hyd_hose_high: 75e4,
	hyd_hose_low: 45e4,
	hyd_hose_to_box: 8e5
}, U5);
var IKCO206_BOX = box({
	steering_box: 2e6,
	hyd_pump: 72e4,
	hyd_pump_repair: 11e5,
	hyd_reservoir: 52e4,
	hyd_hose_high: 72e4,
	hyd_hose_low: 43e4,
	hyd_hose_to_box: 76e4
}, U5);
var DENA_BOX = box({
	steering_box: 25e5,
	hyd_pump: 8e5,
	hyd_pump_repair: 15e5,
	hyd_reservoir: 65e4,
	hyd_hose_high: 8e5,
	hyd_hose_low: 5e5,
	hyd_hose_to_box: 85e4,
	eps_motor: 22e5
}, U5);
var L90_BOX = box({
	steering_box: 32e5,
	hyd_pump: 11e5,
	hyd_pump_repair: 18e5,
	hyd_reservoir: 8e5,
	hyd_hose_high: 11e5,
	hyd_hose_low: 65e4,
	hyd_hose_to_box: 12e5
}, U5);
var VERNA_BOX = box({
	steering_box: 48e5,
	hyd_pump: 18e5,
	hyd_pump_repair: 28e5,
	hyd_reservoir: 11e5,
	hyd_hose_high: 18e5,
	hyd_hose_low: 1e6,
	hyd_hose_to_box: 19e5,
	eps_motor: 32e5
}, E);
var L90 = {
	mount_upper: r(85e4, U),
	mount_front: r(143e4, U),
	mount_round: r(124e4, E),
	sway_bush: r(65e4, U),
	sway_bar: r(35e4, E),
	tie_rod: r(5e5, U),
	inner_tie: r(93e4, U),
	bellows: r(79e4, E),
	control_arm: r(181e4, U),
	arm_bush: r(9e5, E),
	lower_ball: r(115e4, E),
	front_shock: r(124e4, U),
	rear_shock: r(99e4, E),
	knuckle_bearing: r(16e5, E),
	subframe: r(436e4, U),
	steering_cross: r(2e6, E),
	steering_tele: r(2e6, E),
	hyd_hoses: r(124e4, E),
	full_no_shock: r(238e4, E),
	align_manual: r(37e4, E),
	align_machine: r(47e4, E),
	wrenching: r(83e4, E),
	wheel_adj: r(18e4, E),
	...L90_BOX
};
var VERNA = {
	mount_upper: r(13e5, U),
	mount_front: r(13e5, U),
	mount_round: r(16e5, E),
	sway_bush: r(84e4, E),
	sway_bar: r(67e4, E),
	tie_rod: r(8e5, U),
	inner_tie: r(9e5, U),
	bellows: r(116e4, E),
	control_arm: r(2e6, E),
	arm_bush: r(116e4, E),
	lower_ball: r(148e4, E),
	front_shock: r(16e5, U),
	rear_shock: r(128e4, E),
	knuckle_bearing: r(207e4, E),
	subframe: r(55e5, U),
	steering_cross: r(419e4, E),
	steering_tele: r(338e4, E),
	hyd_hoses: r(215e4, E),
	full_no_shock: r(354e4, E),
	align_manual: r(108e4, E),
	align_machine: r(137e4, E),
	wrenching: r(108e4, E),
	wheel_adj: r(23e4, E),
	...VERNA_BOX
};
var FAMILY_RATES = {
	pride: {
		mount_upper: r(65e4, U),
		mount_front: r(65e4, U),
		mount_round: r(55e4, E),
		sway_bush: r(71e4, U),
		tie_rod: r(39e4, U),
		inner_tie: r(71e4, U),
		bellows: r(71e4, E),
		control_arm: r(94e4, U),
		arm_bush: r(4e5, E),
		lower_ball: r(51e4, E),
		front_shock: r(55e4, U),
		rear_shock: r(41e4, E),
		knuckle_bearing: r(71e4, E),
		subframe: r(69e4, U),
		steering_cross: r(144e4, E),
		steering_tele: r(116e4, E),
		full_no_shock: r(13e5, E),
		align_manual: r(37e4, E),
		align_machine: r(47e4, E),
		wrenching: r(37e4, E),
		wheel_adj: r(8e4, E),
		...PRIDE_BOX
	},
	tiba: {
		mount_upper: r(65e4, U),
		mount_front: r(65e4, U),
		mount_round: r(55e4, E),
		sway_bush: r(71e4, U),
		sway_bar: r(45e4, E),
		tie_rod: r(39e4, U),
		inner_tie: r(71e4, U),
		bellows: r(71e4, E),
		control_arm: r(94e4, U),
		arm_bush: r(4e5, E),
		lower_ball: r(51e4, E),
		front_shock: r(55e4, U),
		rear_shock: r(41e4, E),
		knuckle_bearing: r(71e4, E),
		subframe: r(69e4, U),
		steering_cross: r(144e4, E),
		steering_tele: r(116e4, E),
		hyd_hoses: r(11e5, E),
		full_no_shock: r(173e4, E),
		align_manual: r(37e4, E),
		align_machine: r(47e4, E),
		wrenching: r(37e4, E),
		wheel_adj: r(8e4, E),
		...TIBA_BOX
	},
	ikco405: {
		mount_upper: r(59e4, U),
		mount_front: r(42e4, U),
		mount_round: r(82e4, E),
		sway_bush: r(106e4, E),
		sway_bar: r(67e4, E),
		tie_rod: r(58e4, E),
		inner_tie: r(106e4, E),
		bellows: r(91e4, E),
		control_arm: r(14e5, E),
		arm_bush: r(6e5, E),
		lower_ball: r(76e4, E),
		front_shock: r(82e4, U),
		rear_shock: r(66e4, E),
		knuckle_bearing: r(106e4, E),
		subframe: r(242e4, U),
		steering_cross: r(215e4, E),
		steering_tele: r(173e4, E),
		hyd_hoses: r(13e5, E),
		full_no_shock: r(215e4, E),
		align_manual: r(55e4, E),
		align_machine: r(7e5, E),
		wrenching: r(55e4, E),
		wheel_adj: r(12e4, E),
		...IKCO405_BOX
	},
	ikco206: {
		mount_upper: r(55e4, U),
		mount_front: r(47e4, U),
		mount_round: r(82e4, E),
		sway_bush: r(451e3, E),
		sway_bar: r(294e3, E),
		tie_rod: r(294e3, E),
		inner_tie: r(451e3, E),
		bellows: r(91e4, E),
		control_arm: r(588e3, E),
		arm_bush: r(6e5, E),
		lower_ball: r(76e4, E),
		front_shock: r(823e3, E),
		rear_shock: r(66e4, E),
		knuckle_bearing: r(106e4, E),
		subframe: r(285e4, U),
		steering_cross: r(215e4, E),
		steering_tele: r(173e4, E),
		hyd_hoses: r(13e5, E),
		full_no_shock: r(215e4, E),
		align_manual: r(55e4, E),
		align_machine: r(7e5, E),
		wrenching: r(55e4, E),
		wheel_adj: r(12e4, E),
		...IKCO206_BOX
	},
	dena: {
		mount_upper: r(18e5, U),
		mount_front: r(55e4, U),
		mount_round: r(82e4, E),
		sway_bush: r(106e4, E),
		sway_bar: r(67e4, E),
		tie_rod: r(26e4, U),
		inner_tie: r(36e4, U),
		bellows: r(91e4, E),
		control_arm: r(13e5, U),
		arm_bush: r(6e5, E),
		lower_ball: r(76e4, E),
		front_shock: r(82e4, U),
		rear_shock: r(66e4, E),
		knuckle_bearing: r(106e4, E),
		subframe: r(309e4, U),
		steering_cross: r(215e4, E),
		steering_tele: r(173e4, E),
		hyd_hoses: r(13e5, E),
		full_no_shock: r(215e4, E),
		align_manual: r(55e4, E),
		align_machine: r(7e5, E),
		wrenching: r(55e4, E),
		wheel_adj: r(12e4, E),
		...DENA_BOX
	},
	l90: L90,
	megane: scale(L90, 2.6),
	verna: VERNA,
	hyundaiMid: {
		...scale(VERNA, 1.22),
		...box({
			steering_box: 72e5,
			hyd_pump: 24e5,
			hyd_pump_repair: 36e5,
			hyd_reservoir: 14e5,
			hyd_hose_high: 24e5,
			hyd_hose_low: 13e5,
			hyd_hose_to_box: 25e5,
			eps_motor: 42e5
		}, E)
	},
	hyundaiSuv: {
		...scale(VERNA, 1.42),
		...box({
			steering_box: 88e5,
			hyd_pump: 3e6,
			hyd_pump_repair: 44e5,
			hyd_reservoir: 17e5,
			hyd_hose_high: 3e6,
			hyd_hose_low: 16e5,
			hyd_hose_to_box: 31e5,
			eps_motor: 51e5
		}, E)
	},
	kiaCerato: {
		...scale(VERNA, 1.1),
		...box({
			steering_box: 65e5,
			hyd_pump: 22e5,
			hyd_pump_repair: 33e5,
			hyd_reservoir: 125e4,
			hyd_hose_high: 22e5,
			hyd_hose_low: 115e4,
			hyd_hose_to_box: 23e5,
			eps_motor: 38e5
		}, E)
	},
	kiaSuv: {
		...scale(VERNA, 1.28),
		...box({
			steering_box: 8e6,
			hyd_pump: 27e5,
			hyd_pump_repair: 4e6,
			hyd_reservoir: 155e4,
			hyd_hose_high: 27e5,
			hyd_hose_low: 145e4,
			hyd_hose_to_box: 28e5,
			eps_motor: 46e5
		}, E)
	},
	toyotaCompact: {
		...scale(VERNA, 1.12),
		...box({
			steering_box: 68e5,
			hyd_pump: 23e5,
			hyd_pump_repair: 34e5,
			hyd_reservoir: 13e5,
			hyd_hose_high: 23e5,
			hyd_hose_low: 12e5,
			hyd_hose_to_box: 24e5,
			eps_motor: 39e5
		}, E)
	},
	toyotaCamry: {
		...scale(VERNA, 1.25),
		...box({
			steering_box: 82e5,
			hyd_pump: 28e5,
			hyd_pump_repair: 41e5,
			hyd_reservoir: 16e5,
			hyd_hose_high: 28e5,
			hyd_hose_low: 15e5,
			hyd_hose_to_box: 29e5,
			eps_motor: 48e5
		}, E)
	},
	toyotaSuv: {
		...scale(VERNA, 1.38),
		...box({
			steering_box: 88e5,
			hyd_pump: 3e6,
			hyd_pump_repair: 45e5,
			hyd_reservoir: 175e4,
			hyd_hose_high: 3e6,
			hyd_hose_low: 16e5,
			hyd_hose_to_box: 31e5,
			eps_motor: 52e5
		}, E)
	},
	toyotaPrado: {
		...scale(VERNA, 1.65),
		...box({
			steering_box: 105e5,
			hyd_pump: 36e5,
			hyd_pump_repair: 54e5,
			hyd_reservoir: 21e5,
			hyd_hose_high: 36e5,
			hyd_hose_low: 19e5,
			hyd_hose_to_box: 37e5,
			eps_motor: 64e5
		}, E)
	},
	lexusSedan: {
		...scale(VERNA, 1.55),
		...box({
			steering_box: 1e7,
			hyd_pump: 34e5,
			hyd_pump_repair: 51e5,
			hyd_reservoir: 2e6,
			hyd_hose_high: 34e5,
			hyd_hose_low: 18e5,
			hyd_hose_to_box: 35e5,
			eps_motor: 6e6
		}, E)
	},
	lexusSuv: {
		...scale(VERNA, 1.75),
		...box({
			steering_box: 115e5,
			hyd_pump: 39e5,
			hyd_pump_repair: 58e5,
			hyd_reservoir: 23e5,
			hyd_hose_high: 39e5,
			hyd_hose_low: 21e5,
			hyd_hose_to_box: 4e6,
			eps_motor: 68e5
		}, E)
	},
	china: scale(L90, 1.65)
};
/** پکیج تعمیر کامل جلوبندی ۱۴۰۵ — تومان، به‌ازای هر خودرو */
var PACKAGE_1405 = {
	pride: r(266e4, U5),
	tiba: r(301e4, U5),
	saina: r(226e4, U5),
	quick: r(226e4, U5),
	rio: r(326e4, U5),
	mazda: r(286e4, U5),
	"405": r(314e4, U5),
	pars: r(314e4, U5),
	samand: r(314e4, U5),
	"samand-ef7": r(314e4, U5),
	"206": r(286e4, U5),
	"207": r(286e4, U5),
	rana: r(286e4, U5),
	dena: r(314e4, U5),
	"dena-plus": r(314e4, U5),
	l90: r(524e4, U5),
	sandro: r(524e4, U5),
	megane: r(1365e4, U5),
	verna: r(72e5, E),
	accent: r(72e5, E),
	i20: r(74e5, E),
	elantra: r(81e5, E),
	avante: r(78e5, E),
	sonata: r(97e5, E),
	tucson: r(102e5, E),
	ix35: r(102e5, E),
	santafe: r(113e5, E),
	cerato: r(89e5, E),
	optima: r(96e5, E),
	sportage: r(102e5, E),
	sorento: r(113e5, E),
	yaris: r(78e5, E),
	corolla: r(84e5, E),
	camry: r(1e7, E),
	rav4: r(107e5, E),
	hilux: r(12e6, E),
	prado: r(126e5, E),
	landcruiser: r(147e5, E),
	"lexus-is": r(124e5, E),
	"lexus-es": r(131e5, E),
	"lexus-nx": r(135e5, E),
	"lexus-rx": r(142e5, E),
	"jac-s5": r(925e4, U5),
	"jac-j5": r(84e5, U5),
	arrizo5: r(97e5, U5),
	tiggo5: r(875e4, U5),
	x33: r(823e4, U5)
};
var SOURCE_LABEL = {
	"union-1404": "اتحادیه دی ۱۴۰۴",
	estimated: "برآورد به‌روز",
	"union-1405": "اتحادیه ۱۴۰۵"
};
function getCar(carId) {
	return CARS.find((c) => c.id === carId);
}
function getService(serviceId) {
	return SERVICES.find((s) => s.id === serviceId);
}
function getRate(carId, serviceId) {
	if (serviceId === "full_front") return PACKAGE_1405[carId];
	const car = getCar(carId);
	if (!car) return void 0;
	return FAMILY_RATES[car.family]?.[serviceId];
}
function servicesForCar(carId) {
	return SERVICES.flatMap((service) => {
		const rate = getRate(carId, service.id);
		return rate ? [{
			service,
			rate
		}] : [];
	});
}
var RATE_YEAR_NOTE = "پکیج تعمیر کامل خودروهای داخلی از نرخ‌نامه اتحادیه صنف تعمیرکاران خودرو تهران سال ۱۴۰۵ است. اجرت جزءبه‌جزء جلوبندی بر اساس جدول اتحادیه (۸ دی ۱۴۰۴) است. اجرت جعبه فرمان، پمپ و شلنگ هیدرولیک خودروهای داخلی از نرخ اتحادیه مکانیکی ۱۴۰۵ است. خودروهای کره‌ای و ژاپنی و ردیف‌های «برآورد» از نرخ ورنا با ضریب پیچیدگی به‌روز شده‌اند. مبالغ فقط دستمزد است و قطعه، مصرفی و مالیات را شامل نمی‌شود.";
function PrintInvoice({ shopName, shopPhone, shopAddress, customerName, plate, note, carName, lines, partsToman, discountPercent, vatEnabled, unit, persian }) {
	const labor = laborTotal(lines);
	const disc = discountAmount(labor, partsToman, discountPercent);
	const after = afterDiscount(labor, partsToman, discountPercent);
	const vat = vatAmount(lines, partsToman, discountPercent, vatEnabled);
	const total = grandTotal(lines, partsToman, discountPercent, vatEnabled);
	const money = (n) => formatMoney(n, unit, persian);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "print-sheet hidden bg-surface text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-6 flex items-start justify-between border-b-2 border-accent pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "فاکتور اجرت جلوبندی · غرب تکنیک"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-xl font-semibold",
						children: shopName || "غرب تکنیک"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [shopAddress, shopPhone ? ` · ${shopPhone}` : ""]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["تاریخ: ", formatJalali(/* @__PURE__ */ new Date(), persian)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-accent",
						children: "اتحادیه صنف تعمیرکاران خودرو"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 grid grid-cols-3 gap-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "مشتری"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: customerName || "—"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "پلاک"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IranPlatePreview, { value: plate })
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "خودرو"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: carName
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full border-collapse text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-line text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 text-right font-medium",
							children: "شرح خدمات"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 text-center font-medium",
							children: "تعداد"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 text-left font-medium",
							children: "فی"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 text-left font-medium",
							children: "مبلغ"
						})
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-line/60",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
							className: "py-2",
							children: [line.name, line.source === "estimated" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "mr-1 text-xs text-faint",
								children: [
									"(",
									SOURCE_LABEL.estimated,
									")"
								]
							}) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 text-center tabular-nums",
							children: formatNumber(line.qty, persian)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 text-left tabular-nums",
							children: money(line.unitToman)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "py-2 text-left tabular-nums font-medium",
							children: money(line.unitToman * line.qty)
						})
					]
				}, line.id)) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 mr-auto max-w-sm text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "جمع اجرت"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(labor)
						})]
					}),
					partsToman > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "قطعات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(partsToman)
						})]
					}) : null,
					discountPercent > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [
								"تخفیف ",
								formatNumber(discountPercent, persian),
								"٪"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(disc)
						})]
					}) : null,
					vatEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "پس از تخفیف"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(after)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between py-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "مالیات ارزش افزوده ۹٪"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(vat)
						})]
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex justify-between border-t border-line pt-2 text-base font-semibold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "قابل پرداخت" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: money(total)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: tomanToWords(total)
					})
				]
			}),
			note ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-sm text-muted",
				children: ["توضیحات: ", note]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-xs leading-6 text-faint",
				children: "اجرت بر اساس نرخ اتحادیه صنف تعمیرکاران خودرو تهران محاسبه شده است. مبلغ قطعات در صورت درج، جدا از دستمزد است. نرخ‌های برآوردی با علامت مشخص شده‌اند. این فاکتور جنبه اطلاع‌رسانی دارد و جایگزین نرخ‌نامه ممهور اتحادیه نیست."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid grid-cols-2 gap-8 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "امضای مشتری" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-8 border-b border-line" })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "مهر و امضای تعمیرگاه" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-8 border-b border-line" })] })]
			})
		]
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium", {
	variants: { variant: {
		default: "border-transparent bg-accent/10 text-accent",
		outline: "border-line text-muted",
		stamp: "border-transparent bg-stamp/10 text-stamp",
		warn: "border-transparent bg-surface-2 text-muted"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium transition-opacity duration-150 disabled:pointer-events-none disabled:opacity-40 outline-none focus-visible:ring-2 focus-visible:ring-accent/40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			outline: "border border-line bg-surface text-ink hover:bg-surface-2",
			ghost: "text-ink hover:bg-surface-2",
			stamp: "bg-stamp text-accent-fg hover:opacity-90",
			muted: "bg-surface-2 text-ink hover:bg-line"
		},
		size: {
			default: "h-11 rounded-md px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 rounded-lg px-5",
			icon: "size-11 rounded-md",
			iconSm: "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-line bg-surface px-3 py-2 text-sm text-ink", "placeholder:text-faint outline-none transition-opacity duration-150", "focus-visible:ring-2 focus-visible:ring-accent/30", "disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
var Label = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
	ref,
	className: cn("text-xs font-medium text-muted", className),
	...props
}));
Label.displayName = "Label";
function invoiceShareText(opts) {
	const money = (n) => formatMoney(n, opts.unit, opts.persian);
	const labor = laborTotal(opts.lines);
	const after = afterDiscount(labor, opts.partsToman, opts.discountPercent);
	const vat = vatAmount(opts.lines, opts.partsToman, opts.discountPercent, opts.vatEnabled);
	const total = after + vat;
	const rows = opts.lines.map((line) => `• ${line.name} × ${line.qty} — ${money(line.unitToman * line.qty)}`).join("\n");
	const who = [opts.customerName, opts.plate].filter(Boolean).join(" · ");
	return [
		opts.shopName || "غرب تکنیک",
		`تاریخ: ${formatJalali(/* @__PURE__ */ new Date(), opts.persian)}`,
		`خودرو: ${opts.carName}${who ? ` | ${who}` : ""}`,
		"",
		rows,
		"",
		`جمع اجرت: ${money(labor)}`,
		opts.partsToman > 0 ? `قطعات: ${money(opts.partsToman)}` : "",
		opts.discountPercent > 0 ? `تخفیف: ${money(discountAmount(labor, opts.partsToman, opts.discountPercent))}` : "",
		opts.vatEnabled ? `مالیات ارزش افزوده ۹٪: ${money(vat)}` : "",
		`قابل پرداخت: ${money(total)}`,
		tomanToWords(total),
		"",
		"نرخ اتحادیه صنف تعمیرکاران خودرو تهران — فقط دستمزد"
	].filter((line) => line !== "").join("\n");
}
function uid() {
	return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}
function repriced(lines, carId) {
	return lines.flatMap((line) => {
		if (line.custom || !line.serviceId) return [line];
		const rate = getRate(carId, line.serviceId);
		if (!rate) return [];
		return [{
			...line,
			unitToman: rate.toman,
			source: rate.source
		}];
	});
}
function makeLine(carId, serviceId) {
	const service = getService(serviceId);
	const rate = getRate(carId, serviceId);
	if (!service || !rate) return null;
	const qty = service.qtyKind === "perSide" || service.qtyKind === "perUnit" ? Math.min(2, service.maxQty) : 1;
	return {
		id: uid(),
		serviceId,
		name: service.name,
		qty,
		unitToman: rate.toman,
		source: rate.source
	};
}
var useEstimator = create()(persist((set, get) => ({
	carId: "pride",
	query: "",
	category: "all",
	unit: "toman",
	persianDigits: true,
	vatEnabled: false,
	shopName: "غرب تکنیک",
	shopPhone: "",
	shopAddress: "تهران",
	customerName: "",
	plate: "",
	note: "",
	partsToman: 0,
	discountPercent: 0,
	lines: [],
	saved: [],
	setCar: (carId) => set({
		carId,
		lines: repriced(get().lines, carId)
	}),
	setQuery: (query) => set({ query }),
	setCategory: (category) => set({ category }),
	setUnit: (unit) => set({ unit }),
	setPersianDigits: (persianDigits) => set({ persianDigits }),
	setVatEnabled: (vatEnabled) => set({ vatEnabled }),
	setShop: (p) => set(p),
	setCustomer: (p) => set(p),
	setParts: (partsToman) => set({ partsToman: Math.max(0, partsToman) }),
	setDiscount: (discountPercent) => set({ discountPercent: Math.min(100, Math.max(0, discountPercent)) }),
	addService: (serviceId) => {
		const { carId, lines } = get();
		const service = getService(serviceId);
		const existing = lines.find((l) => l.serviceId === serviceId);
		if (existing && service) {
			const next = Math.min(existing.qty + 1, service.maxQty);
			set({ lines: lines.map((l) => l.id === existing.id ? {
				...l,
				qty: next
			} : l) });
			return;
		}
		const line = makeLine(carId, serviceId);
		if (!line) return;
		set({ lines: [...lines, line] });
	},
	addServices: (serviceIds) => {
		const { carId } = get();
		let lines = [...get().lines];
		for (const serviceId of serviceIds) {
			if (lines.some((l) => l.serviceId === serviceId)) continue;
			const line = makeLine(carId, serviceId);
			if (line) lines = [...lines, line];
		}
		set({ lines });
	},
	setQty: (lineId, qty) => {
		set({ lines: get().lines.map((l) => {
			if (l.id !== lineId) return l;
			const max = l.custom ? 20 : getService(l.serviceId ?? "")?.maxQty ?? 10;
			return {
				...l,
				qty: Math.max(1, Math.min(max, qty))
			};
		}) });
	},
	removeLine: (lineId) => set({ lines: get().lines.filter((l) => l.id !== lineId) }),
	addCustom: (name, unitToman) => {
		const trimmed = name.trim();
		if (!trimmed || unitToman <= 0) return;
		set({ lines: [...get().lines, {
			id: uid(),
			name: trimmed,
			qty: 1,
			unitToman,
			custom: true
		}] });
	},
	clearCart: () => set({
		lines: [],
		partsToman: 0,
		discountPercent: 0
	}),
	saveInvoice: (carName) => {
		const s = get();
		const labor = laborTotal(s.lines);
		const total = grandTotal(s.lines, s.partsToman, s.discountPercent, s.vatEnabled);
		const invoice = {
			id: uid(),
			createdAt: (/* @__PURE__ */ new Date()).toISOString(),
			carId: s.carId,
			carName,
			customerName: s.customerName,
			plate: s.plate,
			lines: s.lines,
			partsToman: s.partsToman,
			discountPercent: s.discountPercent,
			vatEnabled: s.vatEnabled,
			laborToman: labor,
			totalToman: total
		};
		set({ saved: [invoice, ...s.saved].slice(0, 40) });
		return invoice;
	},
	deleteSaved: (id) => set({ saved: get().saved.filter((x) => x.id !== id) }),
	loadSaved: (id) => {
		const inv = get().saved.find((x) => x.id === id);
		if (!inv) return;
		set({
			carId: inv.carId,
			lines: inv.lines,
			partsToman: inv.partsToman,
			discountPercent: inv.discountPercent,
			vatEnabled: inv.vatEnabled ?? false,
			customerName: inv.customerName,
			plate: inv.plate
		});
	}
}), {
	name: "jelobandi-estimator-v2",
	skipHydration: true,
	partialize: (s) => ({
		carId: s.carId,
		unit: s.unit,
		persianDigits: s.persianDigits,
		vatEnabled: s.vatEnabled,
		shopName: s.shopName,
		shopPhone: s.shopPhone,
		shopAddress: s.shopAddress,
		customerName: s.customerName,
		plate: s.plate,
		note: s.note,
		partsToman: s.partsToman,
		discountPercent: s.discountPercent,
		lines: s.lines,
		saved: s.saved
	})
}));
var SYMPTOMS = [
	{
		id: "full",
		name: "سرویس کامل",
		hint: "دستمزد پکیج تعمیر کامل جلوبندی طبق نرخ ۱۴۰۵",
		serviceIds: ["full_front"]
	},
	{
		id: "knock",
		name: "صدای تق‌تق از جلو",
		hint: "معمولاً سیبک، طبق یا بوش معیوب است",
		serviceIds: [
			"tie_rod",
			"lower_ball",
			"control_arm",
			"arm_bush"
		]
	},
	{
		id: "bump",
		name: "ضربه در دست‌انداز",
		hint: "بوش موج‌گیر، کمک‌فنر یا طبق را بررسی کنید",
		serviceIds: [
			"sway_bush",
			"sway_bar",
			"front_shock",
			"arm_bush"
		]
	},
	{
		id: "pull",
		name: "کشیدن به یک سمت",
		hint: "سیبک فرمان، طبق و میزان فرمان",
		serviceIds: [
			"align_machine",
			"tie_rod",
			"control_arm"
		]
	},
	{
		id: "shake",
		name: "لرزش فرمان",
		hint: "بلبرینگ چرخ، قرقری یا میزان فرمان",
		serviceIds: [
			"align_machine",
			"knuckle_bearing",
			"inner_tie",
			"front_shock"
		]
	},
	{
		id: "soft",
		name: "نرمی یا روغن‌ریزی کمک",
		hint: "کمک‌فنر جلو باید تعویض شود",
		serviceIds: ["front_shock"]
	},
	{
		id: "play",
		name: "بازی غربیلک فرمان",
		hint: "جعبه فرمان، قرقری، چهارشاخه یا گردگیر فرمان",
		serviceIds: [
			"steering_box",
			"inner_tie",
			"steering_cross",
			"bellows",
			"wheel_adj"
		]
	},
	{
		id: "hyd",
		name: "سختی یا نشتی فرمان",
		hint: "پمپ، شلنگ یا جعبه فرمان هیدرولیک را بررسی کنید",
		serviceIds: [
			"steering_box",
			"hyd_pump",
			"hyd_hose_high",
			"hyd_reservoir"
		]
	},
	{
		id: "tire",
		name: "سایش نامنظم لاستیک",
		hint: "طبق، سیبک و میزان فرمان با دستگاه",
		serviceIds: [
			"align_machine",
			"control_arm",
			"tie_rod"
		]
	}
];
function UnionSeal() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 64 64",
		className: "size-12 shrink-0",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "30",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "32",
				cy: "32",
				r: "24",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "0.75"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 38h32M20 38c0-6 4-12 12-14 8 2 12 8 12 14",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.8",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22",
				cy: "39",
				r: "3.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "42",
				cy: "39",
				r: "3.2",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.6"
			})
		]
	});
}
function Estimator() {
	const [tab, setTab] = (0, import_react.useState)("estimate");
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [customName, setCustomName] = (0, import_react.useState)("");
	const [customPrice, setCustomPrice] = (0, import_react.useState)("");
	const [invoiceOpen, setInvoiceOpen] = (0, import_react.useState)(false);
	const [brandFilter, setBrandFilter] = (0, import_react.useState)("saipa");
	const [symptomId, setSymptomId] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		Promise.resolve(useEstimator.persist.rehydrate()).then(() => {
			const state = useEstimator.getState();
			const next = getCar(state.carId);
			if (next) setBrandFilter(next.brand);
			if (!state.shopName || state.shopName === "تعمیرگاه جلوبندی") state.setShop({ shopName: "غرب تکنیک" });
		});
	}, []);
	const carId = useEstimator((s) => s.carId);
	const query = useEstimator((s) => s.query);
	const category = useEstimator((s) => s.category);
	const unit = useEstimator((s) => s.unit);
	const persian = useEstimator((s) => s.persianDigits);
	const vatEnabled = useEstimator((s) => s.vatEnabled);
	const lines = useEstimator((s) => s.lines);
	const partsToman = useEstimator((s) => s.partsToman);
	const discountPercent = useEstimator((s) => s.discountPercent);
	const shopName = useEstimator((s) => s.shopName);
	const shopPhone = useEstimator((s) => s.shopPhone);
	const shopAddress = useEstimator((s) => s.shopAddress);
	const customerName = useEstimator((s) => s.customerName);
	const plate = useEstimator((s) => s.plate);
	const note = useEstimator((s) => s.note);
	const saved = useEstimator((s) => s.saved);
	const setCar = useEstimator((s) => s.setCar);
	const setQuery = useEstimator((s) => s.setQuery);
	const setCategory = useEstimator((s) => s.setCategory);
	const setUnit = useEstimator((s) => s.setUnit);
	const setPersianDigits = useEstimator((s) => s.setPersianDigits);
	const setVatEnabled = useEstimator((s) => s.setVatEnabled);
	const addService = useEstimator((s) => s.addService);
	const addServices = useEstimator((s) => s.addServices);
	const setQty = useEstimator((s) => s.setQty);
	const removeLine = useEstimator((s) => s.removeLine);
	const addCustom = useEstimator((s) => s.addCustom);
	const clearCart = useEstimator((s) => s.clearCart);
	const setParts = useEstimator((s) => s.setParts);
	const setDiscount = useEstimator((s) => s.setDiscount);
	const setShop = useEstimator((s) => s.setShop);
	const setCustomer = useEstimator((s) => s.setCustomer);
	const saveInvoice = useEstimator((s) => s.saveInvoice);
	const deleteSaved = useEstimator((s) => s.deleteSaved);
	const loadSaved = useEstimator((s) => s.loadSaved);
	const carName = (getCar(carId) ?? CARS[0])?.name ?? "پراید";
	const money = (n) => formatMoney(n, unit, persian);
	const labor = laborTotal(lines);
	const total = grandTotal(lines, partsToman, discountPercent, vatEnabled);
	const vat = vatAmount(lines, partsToman, discountPercent, vatEnabled);
	const disc = discountAmount(labor, partsToman, discountPercent);
	const pkg = getRate(carId, "full_front");
	const symptom = SYMPTOMS.find((s) => s.id === symptomId) ?? null;
	const highlight = new Set(symptom?.serviceIds ?? []);
	const hasPackage = lines.some((l) => l.serviceId === "full_front");
	const hasOther = lines.some((l) => l.serviceId && l.serviceId !== "full_front" && !l.custom);
	const catalog = (0, import_react.useMemo)(() => {
		const q = query.trim();
		return servicesForCar(carId).filter(({ service }) => {
			if (category !== "all" && service.category !== category) return false;
			if (highlight.size && !q && category === "all" && !highlight.has(service.id)) {}
			if (!q) return true;
			return service.name.includes(q);
		});
	}, [
		carId,
		category,
		query,
		highlight.size
	]);
	const grouped = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const item of catalog) {
			const list = map.get(item.service.category) ?? [];
			list.push(item);
			map.set(item.service.category, list);
		}
		return CATEGORIES.filter((c) => map.has(c.id)).map((c) => ({
			...c,
			items: map.get(c.id) ?? []
		}));
	}, [catalog]);
	const brandCars = CARS.filter((c) => brandFilter === "all" || c.brand === brandFilter);
	function handlePrint() {
		window.print();
	}
	function handleSave() {
		saveInvoice(carName);
		toast.success("فاکتور ذخیره شد");
		setTab("saved");
		setInvoiceOpen(false);
	}
	async function handleCopy() {
		const text = invoiceShareText({
			shopName,
			carName,
			customerName,
			plate,
			lines,
			partsToman,
			discountPercent,
			vatEnabled,
			unit,
			persian
		});
		try {
			await navigator.clipboard.writeText(text);
			toast.success("متن فاکتور کپی شد");
		} catch {
			toast.error("کپی انجام نشد");
		}
	}
	function submitCustom(e) {
		e.preventDefault();
		const n = Number(customPrice.replace(/[^\d.]/g, ""));
		addCustom(customName, unit === "rial" ? n / 10 : n);
		setCustomName("");
		setCustomPrice("");
	}
	function pickCar(id) {
		const next = getCar(id);
		if (next) setBrandFilter(next.brand);
		setCar(id);
	}
	function pickBrand(id) {
		setBrandFilter(id);
		if (id === "all") return;
		if (getCar(carId)?.brand === id) return;
		const first = CARS.find((c) => c.brand === id);
		if (first) setCar(first.id);
	}
	const invoiceProps = {
		customerName,
		plate,
		note,
		carName,
		lines,
		partsToman,
		discountPercent,
		vatEnabled,
		unit,
		persian,
		money,
		labor,
		total,
		vat,
		disc,
		onQty: setQty,
		onRemove: removeLine,
		onCustomName: setCustomName,
		onCustomPrice: setCustomPrice,
		customName,
		customPrice,
		onCustomSubmit: submitCustom,
		onParts: setParts,
		onDiscount: setDiscount,
		onCustomer: setCustomer,
		onPrint: handlePrint,
		onSave: handleSave,
		onCopy: handleCopy,
		onClear: clearCart,
		hasPackage,
		hasOther
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-svh overflow-x-hidden bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "no-print sticky top-0 z-20 border-b border-line/80 bg-bg/90 backdrop-blur-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnionSeal, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
											className: "text-lg font-semibold tracking-tight md:text-xl",
											children: "نرخ‌نامه جلوبندی خودرو"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, { children: ["۱۴۰۵ · ", formatJalali(/* @__PURE__ */ new Date(), persian)] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-semibold text-accent",
										children: "غرب تکنیک"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-xs text-muted",
										children: "اجرت مصوب اتحادیه صنف تعمیرکاران خودرو تهران"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "icon",
								"aria-label": "تنظیمات تعمیرگاه",
								onClick: () => setSettingsOpen((v) => !v),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, {})
							})
						]
					}),
					settingsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl gap-3 border-t border-line px-4 py-4 md:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "shop-name",
									children: "نام تعمیرگاه"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "shop-name",
									value: shopName,
									onChange: (e) => setShop({ shopName: e.target.value })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "shop-phone",
									children: "تلفن"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "shop-phone",
									value: shopPhone,
									dir: "ltr",
									className: "text-right",
									onChange: (e) => setShop({ shopPhone: e.target.value })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "shop-addr",
									children: "آدرس"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "shop-addr",
									value: shopAddress,
									onChange: (e) => setShop({ shopAddress: e.target.value })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-end gap-2 md:col-span-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: unit === "toman",
										onClick: () => setUnit("toman"),
										label: "تومان"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: unit === "rial",
										onClick: () => setUnit("rial"),
										label: "ریال"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: persian,
										onClick: () => setPersianDigits(!persian),
										label: "اعداد فارسی"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
										on: vatEnabled,
										onClick: () => setVatEnabled(!vatEnabled),
										label: "مالیات ۹٪"
									})
								]
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "mx-auto flex max-w-6xl gap-1 overflow-x-auto px-4 pb-2",
						children: [
							["estimate", "برآورد اجرت"],
							["table", "جدول نرخ‌ها"],
							["saved", "فاکتورهای ذخیره‌شده"]
						].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setTab(id),
							className: cn("h-11 shrink-0 rounded-md px-3 text-sm font-medium transition-opacity duration-150", tab === id ? "bg-accent text-accent-fg" : "text-muted hover:bg-surface-2"),
							children: [label, id === "saved" && saved.length > 0 ? ` (${formatNumber(saved.length, persian)})` : ""]
						}, id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative mx-auto min-w-0 max-w-6xl px-4 py-5 pb-28 lg:pb-5",
				children: [
					tab === "estimate" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid min-w-0 gap-5 lg:grid-cols-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "no-print min-w-0 space-y-4 lg:col-span-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-medium text-muted",
											children: "انتخاب خودرو"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
												active: brandFilter === "all",
												onClick: () => pickBrand("all"),
												children: "همه"
											}), BRANDS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
												active: brandFilter === b.id,
												onClick: () => pickBrand(b.id),
												children: b.name
											}, b.id))]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "max-w-full overflow-x-auto pb-1",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex w-max gap-2 md:w-full md:flex-wrap",
												children: brandCars.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => pickCar(item.id),
													className: cn("h-11 shrink-0 rounded-lg px-3 text-sm font-medium ring-1 transition-opacity duration-150", carId === item.id ? "bg-accent text-accent-fg ring-accent" : "bg-surface text-ink ring-line hover:bg-surface-2"),
													children: item.name
												}, item.id))
											})
										})
									]
								}),
								pkg ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-3 rounded-xl border border-line bg-surface px-4 py-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-xs font-medium text-muted",
												children: ["تعمیر کامل جلوبندی · ", carName]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-2xl font-semibold tabular-nums tracking-tight",
												children: money(pkg.toman)
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xs text-faint",
												children: "نرخ مصوب اتحادیه ۱۴۰۵ · فقط دستمزد، بدون قطعه"
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => addService("full_front"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "افزودن به فاکتور"]
									})]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-medium text-muted",
											children: "علت مراجعه"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex flex-wrap gap-2",
											children: SYMPTOMS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
												active: symptomId === s.id,
												onClick: () => setSymptomId((cur) => cur === s.id ? null : s.id),
												children: s.name
											}, s.id))
										}),
										symptom ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-2 rounded-lg bg-surface-2 px-3 py-2 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "min-w-0 flex-1 text-muted",
												children: symptom.hint
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
												size: "sm",
												variant: "outline",
												onClick: () => addServices(symptom.serviceIds),
												children: "افزودن پیشنهادی"
											})]
										}) : null
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-faint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: query,
										onChange: (e) => setQuery(e.target.value),
										placeholder: "جستجوی خدمت؛ جعبه فرمان، سیبک، طبق، کمک…",
										className: "pr-10"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "max-w-full overflow-x-auto pb-1",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex w-max gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
											active: category === "all",
											onClick: () => setCategory("all"),
											children: "همه"
										}), CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
											active: category === c.id,
											onClick: () => setCategory(c.id),
											children: c.name
										}, c.id))]
									})
								}),
								grouped.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-line bg-surface px-5 py-10 text-center text-sm text-muted",
									children: [
										"خدمتی با این جستجو برای ",
										carName,
										" پیدا نشد."
									]
								}) : grouped.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "overflow-hidden rounded-xl border border-line bg-surface",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "border-b border-line bg-surface-2/60 px-4 py-2.5 text-sm font-semibold",
										children: group.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: group.items.map(({ service, rate }) => {
										const inCart = lines.find((l) => l.serviceId === service.id);
										const marked = highlight.has(service.id);
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: cn("flex items-center gap-3 border-b border-line/70 px-4 py-3 last:border-b-0", marked && "bg-accent/5"),
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "min-w-0 flex-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-sm font-medium",
														children: service.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
														className: "mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: service.unitLabel }),
															rate.source !== "union-1404" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
																variant: rate.source === "estimated" ? "warn" : "default",
																children: SOURCE_LABEL[rate.source]
															}) : null,
															inCart ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
																variant: "outline",
																children: ["در فاکتور × ", formatNumber(inCart.qty, persian)]
															}) : null
														]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "shrink-0 text-sm font-semibold tabular-nums",
													children: money(rate.toman)
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
													size: "icon",
													variant: inCart ? "default" : "outline",
													"aria-label": `افزودن ${service.name}`,
													onClick: () => addService(service.id),
													children: inCart ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
												})
											]
										}, service.id);
									}) })]
								}, group.id)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs leading-6 text-faint",
									children: RATE_YEAR_NOTE
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
							className: "no-print hidden min-w-0 lg:sticky lg:top-28 lg:block lg:self-start",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceCard, { ...invoiceProps })
						})]
					}) : null,
					tab === "table" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateTable, {
						unit,
						persian,
						carId
					}) : null,
					tab === "saved" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SavedList, {
						saved,
						persian,
						unit,
						onLoad: (id) => {
							loadSaved(id);
							const inv = saved.find((x) => x.id === id);
							const next = inv ? getCar(inv.carId) : void 0;
							if (next) setBrandFilter(next.brand);
							setTab("estimate");
							setInvoiceOpen(true);
						},
						onDelete: deleteSaved
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintInvoice, {
				shopName,
				shopPhone,
				shopAddress,
				customerName,
				plate,
				note,
				carName,
				lines,
				partsToman,
				discountPercent,
				vatEnabled,
				unit,
				persian
			}),
			tab === "estimate" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "no-print fixed inset-x-3 bottom-4 z-20 rounded-xl border border-line bg-surface p-3 shadow-lg lg:hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: carName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-semibold tabular-nums",
							children: money(total)
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => setInvoiceOpen(true),
						children: "مشاهده فاکتور"
					})]
				})
			}) : null,
			invoiceOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print fixed inset-0 z-40 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "بستن فاکتور",
					className: "absolute inset-0 bg-ink/40",
					onClick: () => setInvoiceOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 max-h-[92svh] overflow-auto rounded-t-2xl bg-bg p-3 pb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1 w-10 rounded-full bg-line" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceCard, { ...invoiceProps })]
				})]
			}) : null
		]
	});
}
function Toggle({ on, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: on ? "default" : "outline",
		size: "sm",
		onClick,
		children: label
	});
}
function FilterChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-11 shrink-0 rounded-full px-3 text-sm font-medium transition-opacity duration-150", active ? "bg-accent text-accent-fg" : "bg-surface text-muted ring-1 ring-line"),
		children
	});
}
function Row({ label, value, strong }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center justify-between", strong && "text-base font-semibold"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: strong ? "" : "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children: value
		})]
	});
}
function InvoiceCard(p) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex max-h-none flex-col overflow-hidden rounded-xl border border-line bg-surface lg:max-h-[calc(100svh-8.5rem)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: ["فاکتور اجرت · ", p.carName]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg font-semibold tabular-nums",
					children: p.money(p.total)
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 border-t border-line p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "cust",
						children: "نام مشتری"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "cust",
						value: p.customerName,
						onChange: (e) => p.onCustomer({ customerName: e.target.value })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "پلاک" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IranPlateInput, {
						value: p.plate,
						onChange: (plate) => p.onCustomer({ plate })
					})]
				})]
			}),
			p.hasPackage && p.hasOther ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-3 mb-2 rounded-md bg-stamp/10 px-3 py-2 text-xs leading-5 text-stamp",
				children: "پکیج کامل و ردیف‌های جزئی هم‌زمان در فاکتور هستند؛ ممکن است اجرت دو بار محاسبه شود."
			}) : null,
			p.lines.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 py-8 text-center text-sm text-muted",
				children: "خدمت را از فهرست اضافه کنید."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "min-h-0 flex-1 overflow-auto border-y border-line",
				children: p.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-start gap-2 px-3 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-snug",
							children: line.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-xs tabular-nums text-muted",
							children: [p.money(line.unitToman), line.source === "estimated" ? " · برآورد" : ""]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								"aria-label": "کم کردن",
								onClick: () => line.qty <= 1 ? p.onRemove(line.id) : p.onQty(line.id, line.qty - 1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-6 text-center text-sm tabular-nums",
								children: formatNumber(line.qty, p.persian)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								"aria-label": "افزودن",
								onClick: () => p.onQty(line.id, line.qty + 1),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								"aria-label": "حذف",
								onClick: () => p.onRemove(line.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})
						]
					})]
				}, line.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: p.onCustomSubmit,
				className: "grid shrink-0 grid-cols-6 gap-2 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "col-span-3",
						placeholder: "ردیف دستی",
						value: p.customName,
						onChange: (e) => p.onCustomName(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "col-span-2 text-right",
						placeholder: p.unit === "rial" ? "ریال" : "تومان",
						inputMode: "numeric",
						dir: "ltr",
						value: p.customPrice,
						onChange: (e) => p.onCustomPrice(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "outline",
						size: "icon",
						"aria-label": "افزودن ردیف",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 space-y-2 px-3 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "parts",
							children: "مبلغ قطعات"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "parts",
							inputMode: "numeric",
							dir: "ltr",
							className: "text-right tabular-nums",
							value: p.partsToman ? String(p.unit === "rial" ? p.partsToman * 10 : p.partsToman) : "",
							onChange: (e) => {
								const n = Number(e.target.value.replace(/[^\d]/g, "")) || 0;
								p.onParts(p.unit === "rial" ? n / 10 : n);
							}
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "disc",
							children: "تخفیف ٪"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "disc",
							inputMode: "numeric",
							dir: "ltr",
							className: "text-right tabular-nums",
							value: p.discountPercent || "",
							onChange: (e) => p.onDiscount(Number(e.target.value.replace(/[^\d]/g, "")) || 0)
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						htmlFor: "note",
						children: "توضیحات"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "note",
						value: p.note,
						onChange: (e) => p.onCustomer({ note: e.target.value })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "shrink-0 space-y-1 border-t border-line bg-surface-2/50 px-4 py-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "جمع اجرت",
						value: p.money(p.labor)
					}),
					p.partsToman > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "قطعات",
						value: p.money(p.partsToman)
					}) : null,
					p.discountPercent > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: `تخفیف ${formatNumber(p.discountPercent, p.persian)}٪`,
						value: p.money(p.disc)
					}) : null,
					p.vatEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "مالیات ارزش افزوده ۹٪",
						value: p.money(p.vat)
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "قابل پرداخت",
						value: p.money(p.total),
						strong: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "pt-1 text-xs leading-5 text-muted",
						children: tomanToWords(p.total)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid shrink-0 grid-cols-2 gap-2 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: p.onPrint,
						disabled: p.lines.length === 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), "چاپ فاکتور"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: p.onSave,
						disabled: p.lines.length === 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, {}), "ذخیره"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: p.onCopy,
						disabled: p.lines.length === 0,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "کپی متن"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "text-stamp",
						onClick: p.onClear,
						disabled: p.lines.length === 0,
						children: "پاک کردن"
					})
				]
			})
		]
	});
}
function RateTable({ unit, persian, carId }) {
	const [q, setQ] = (0, import_react.useState)("");
	const [onlyCar, setOnlyCar] = (0, import_react.useState)(true);
	const money = (n) => formatMoney(n, unit, persian);
	const rows = SERVICES.filter((service) => !q || service.name.includes(q));
	const cols = onlyCar ? CARS.filter((c) => c.id === carId) : CARS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "no-print min-w-0 space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 text-faint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "جستجو در جدول نرخ‌ها",
						className: "pr-10"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					on: onlyCar,
					onClick: () => setOnlyCar((v) => !v),
					label: onlyCar ? "فقط این خودرو" : "همه خودروها"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-auto rounded-xl border border-line bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-max min-w-full border-collapse text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "sticky top-0 bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "sticky right-0 bg-surface-2 px-3 py-2 text-right font-medium",
							children: "خدمت"
						}), cols.map((car) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-3 py-2 text-left font-medium whitespace-nowrap",
							children: car.name
						}, car.id))] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-t border-line/70",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
							className: "sticky right-0 bg-surface px-3 py-2 text-right font-medium",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block",
								children: service.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-normal text-muted",
								children: service.unitLabel
							})]
						}), cols.map((car) => {
							const cell = getRate(car.id, service.id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-3 py-2 text-left tabular-nums",
								children: cell ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn(cell.source === "estimated" && "text-muted", cell.source === "union-1405" && "text-accent"),
									children: money(cell.toman)
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-faint",
									children: "—"
								})
							}, car.id);
						})]
					}, service.id)) })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-6 text-faint",
				children: RATE_YEAR_NOTE
			})
		]
	});
}
function SavedList({ saved, persian, unit, onLoad, onDelete }) {
	if (saved.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "no-print rounded-xl border border-line bg-surface px-5 py-16 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium",
			children: "فاکتور ذخیره‌شده‌ای نیست"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted",
			children: "پس از محاسبه اجرت، فاکتور را ذخیره کنید."
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "no-print space-y-2",
		children: saved.map((inv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex flex-wrap items-center gap-3 rounded-xl border border-line bg-surface px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [
							inv.carName,
							inv.customerName ? ` · ${inv.customerName}` : "",
							inv.plate ? ` · ${inv.plate}` : ""
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							formatJalali(new Date(inv.createdAt), persian),
							" ·",
							" ",
							formatNumber(inv.lines.length, persian),
							" ردیف"
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold tabular-nums",
					children: formatMoney(inv.totalToman, unit, persian)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => onLoad(inv.id),
					children: "باز کردن"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					variant: "ghost",
					"aria-label": "حذف فاکتور",
					onClick: () => onDelete(inv.id),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
				})
			]
		}, inv.id))
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Estimator, {});
}
//#endregion
export { Home as component };
